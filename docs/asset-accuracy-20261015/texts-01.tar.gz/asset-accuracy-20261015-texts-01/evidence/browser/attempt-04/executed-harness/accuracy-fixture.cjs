// In-memory synthetic IPC only. Never calls a provider, model, target or database.
module.exports = function accuracyFixture(options = {}) {
 const qa=window.__QA__, old=window.__TAURI_INTERNALS__.invoke, clone=x=>JSON.parse(JSON.stringify(x));
 const now='2026-10-15T10:00:00Z';
 Object.assign(qa.profiles[0].settings,{runProbe:false,runRefine:false});
 qa.profiles.push({...clone(qa.profiles[0]),id:2,name:'Synthetic probe profile',isDefault:false,settings:{...qa.profiles[0].settings,runProbe:true,runRefine:false}});
 const summary=(x={})=>({schemaVersion:1,executionComplete:true,coverageComplete:true,queries:3,completedQueries:3,failedQueries:0,truncatedQueries:0,partialQueries:0,invalidRecords:0,candidates:37,importedCandidates:35,probedAssets:31,reusedPages:0,errorCategories:[],reasons:[],...x});
 const run=(id,name,x={})=>({id,name,projectId:1,profileId:1,projectName:qa.projects[0].name,pipeline:'full',status:'completed',stage:'completed',progress:100,processed:37,total:37,outputDir:'',error:'',createdAt:now,collectionSummary:summary(),...x});
 qa.accuracyRuns=[
  run(101,'Synthetic partial collection',{collectionSummary:summary({coverageComplete:false,truncatedQueries:1,reasons:['page_limit'],retention:{scope:'owned_collection_files_and_control_metadata_only',runBytes:12,projectBytes:34,globalBytes:56,expiredFiles:2,expiredBytes:8,unmanagedRuns:3,unknownFiles:4,historyTruncated:true,maxRunBytes:100,maxProjectBytes:200,maxGlobalBytes:300,maxPages:20,maxAgeSeconds:3600}})}),
  run(102,'Synthetic failed collection',{status:'failed',stage:'collect',error:'Synthetic provider failure',collectionSummary:summary({executionComplete:false,coverageComplete:false,completedQueries:1,failedQueries:2,candidates:17,importedCandidates:0,probedAssets:null,errorCategories:['provider_quota','resource_limited','collection_storage_unavailable'],reasons:['collection_failed','redacted_locator']})}),
  run(103,'Synthetic legacy unknown',{collectionSummary:null,error:'coverage_complete=true; 100% complete'}),
  run(104,'Synthetic contradictory evidence',{collectionSummary:summary({failedQueries:1})}),
 ];
 const asset=(id,title,extra={},x={})=>({id,projectId:1,assetKey:`https://asset-${id}.example.test/`,company:'Synthetic discovery label',host:`https://asset-${id}.example.test/`,link:`https://asset-${id}.example.test/`,ip:'192.0.2.55',port:'443',protocol:'https',domain:`asset-${id}.example.test`,title,statusCode:'200',probeOutcome:'web_alive',probeEntryState:'web',reviewTier:'P2',contentCategory:'normal',score:'50',decision:'pending',note:'',ownershipStatus:'unreviewed',ownershipConfidence:0,authorizationStatus:'unknown',exposureEligible:false,ownershipSource:'',ownershipReason:'',isDeleted:false,firstSeen:now,lastSeen:now,extra,sentinelStatus:'not_sent',sentinelScanCount:0,projectFirstSeen:now,projectLastSeen:now,lastRunId:101,projectName:qa.projects[0].name,hasLogin:-1,hasRegister:-1,entryOpenedAt:null,...x});
 qa.accuracyAssets=[
  asset(801,'Synthetic candidate',{}, {probeOutcome:'',statusCode:''}),
  asset(802,'Synthetic changed endpoint',{collection_provider_observed_at:'2026-10-12 01:00:00',collection_received_at:'2026-10-15T08:00:00Z',probe_checked_at:'2026-10-15T09:00:00Z',probe_history_reason:'endpoint_changed',probe_observed_ip:'192.0.2.44',probe_observed_endpoint:'https://old.example.test/',probe_observed_endpoint_basis:'legacy_candidate_endpoint'}),
  asset(803,'Synthetic timezone unknown',{probe_checked_at:'2026-10-15 09:00:00'}),
  asset(804,'Synthetic skipped attempt',{collection_received_at:'2026-10-15T08:00:00Z',probe_checked_at:'2026-10-15T09:00:00Z'},{probeOutcome:'skipped',statusCode:''}),
  asset(805,'Synthetic legacy historical',{}),
  asset(806,'Synthetic recorded observation',{collection_provider_observed_at:'2026-10-12T01:00:00Z',collection_received_at:'2026-10-15T08:00:00Z',probe_checked_at:'2026-10-15T09:00:00Z'}),
 ];
 qa.accuracyStarts=[];
 window.__TAURI_INTERNALS__.invoke=async(cmd,args={})=>{
  if(!['dashboard_stats','list_runs','list_assets','list_targets','start_job'].includes(cmd))return old(cmd,args);
  qa.calls.push({cmd,args:clone(args)});
  if(cmd==='dashboard_stats')return {projectCount:3,assetCount:6,aliveCount:4,pendingCount:6,newCount:0,changedCount:0,blockedCount:0,runningJobs:0};
  if(cmd==='list_runs')return clone(args.projectId===undefined||args.projectId===1?qa.accuracyRuns:[]);
  if(cmd==='list_targets')return args.projectId===1?[{id:1,projectId:1,targetType:'domain',value:'fixture.example.test',enabled:true,createdAt:now}]:[];
  if(cmd==='list_assets'){
   const q=args.query;if(q.projectId!==1)throw Error('synthetic_accuracy_project_mismatch');
   if(!Number.isSafeInteger(q.page)||q.page<1||![50,100,200].includes(q.pageSize))throw Error('synthetic_accuracy_page_contract');
   const rows=qa.accuracyAssets.filter(a=>!q.search||a.title.includes(q.search));
   return {items:clone(rows.slice((q.page-1)*q.pageSize,q.page*q.pageSize)),total:rows.length,memberTotal:rows.length,page:q.page,pageSize:q.pageSize,summary:{all:rows.length,pending:rows.length,uncertain:0,confirmed:0,rejected:0,notApplicable:0,sentToAgent:0}};
  }
  const i=args.input;if(i.projectId!==1||![1,2].includes(i.profileId)||!['full','collect','reprobe'].includes(i.pipeline))throw Error('synthetic_accuracy_start_contract');
  qa.mutations.push({cmd,args:clone(args)});qa.accuracyStarts.push(clone(i));
  const id=900+qa.accuracyStarts.length;qa.accuracyRuns.unshift(run(id,'Synthetic newly admitted task',{profileId:i.profileId,status:'queued',stage:'queued',progress:0,collectionSummary:null}));return id;
 };
};
