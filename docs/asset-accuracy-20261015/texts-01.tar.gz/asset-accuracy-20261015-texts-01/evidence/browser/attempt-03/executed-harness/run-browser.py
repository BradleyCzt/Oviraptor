#!/usr/bin/env python3
import datetime,hashlib,json,pathlib,re,subprocess,sys,time
ROOT=pathlib.Path('/workspace/Oviraptor-asset-accuracy-20261015')
SCRIPTS=pathlib.Path(__file__).parent
prefix=sys.argv[1]
assert re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]*',prefix)
OUT=SCRIPTS.parent/prefix
OUT.mkdir(exist_ok=False)
# Preserve the exact executed QA inputs independently of later harness revisions.
import shutil
(OUT/'executed-harness').mkdir()
for p in SCRIPTS.glob('*'):
 if p.is_file(): shutil.copy2(p,OUT/'executed-harness'/p.name)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,v):
 with (OUT/name).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def snap():
 files=set(ROOT.glob('src/**/*'))|set(ROOT.glob('dist/**/*'))|set(ROOT.glob('tools/qa/chat-ui/*'))|set(SCRIPTS.glob('*'))
 for name in ['package.json','package-lock.json','yarn.lock','vite.config.ts','tsconfig.json','index.html','tools/asset_accuracy_ui_harness.cjs','tools/test_asset_accuracy_ui.cjs']:files.add(ROOT/name)
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'files':{str(p):sha(p) for p in sorted(files) if p.is_file()}}
before=snap();save('inputs-before.json',before)
build=json.loads(pathlib.Path('/workspace/validation/asset-accuracy-20261015/frontend-tests/build-04-after.json').read_text())
mismatch=[name for name,h in build['files'].items() if name.startswith('src/') and before['files'].get(str(ROOT/name))!=h]
if mismatch:raise RuntimeError('Frontend source differs from bound npm build: '+repr(mismatch))
cmd=['node',str(SCRIPTS/'browser-accuracy.cjs'),str(OUT)]
started=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic()
with (OUT/'browser.log').open('x') as f:r=subprocess.run(cmd,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
duration=round(time.monotonic()-tick,3);after=snap();save('inputs-after.json',after)
changes=sorted(n for n in before['files'].keys()|after['files'].keys() if before['files'].get(n)!=after['files'].get(n))
result=json.loads((OUT/'browser-results.json').read_text()) if (OUT/'browser-results.json').exists() else None
record={'scope':'Actual existing npm production dist in Chromium with synthetic IPC; source/build/input SHA closure recorded; not Tauri/DB/provider acceptance','command':cmd,'startedAtUtc':started,'durationSeconds':duration,'exitCode':r.returncode,'headBefore':before['head'],'headAfter':after['head'],'inputCount':len(before['files']),'changedInputs':changes,'inputsUnchanged':not changes,'frontendMatchesNpmBuildSnapshot':not mismatch,'counts':result['counts'] if result else None,'browserLogSha256':sha(OUT/'browser.log'),'runnerSha256':sha(pathlib.Path(__file__))}
save('execution-result.json',record)
print(json.dumps(record));sys.exit(r.returncode or int(bool(changes)))
