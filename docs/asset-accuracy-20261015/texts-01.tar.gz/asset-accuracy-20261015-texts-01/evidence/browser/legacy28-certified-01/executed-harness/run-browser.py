#!/usr/bin/env python3
import datetime,hashlib,importlib.util,json,pathlib,re,shutil,subprocess,sys,time
ROOT=pathlib.Path('/workspace/Oviraptor-asset-accuracy-20261015');BASE=pathlib.Path('/workspace/validation/asset-accuracy-20261015');SCRIPTS=pathlib.Path(__file__).parent
EXPECTED='34e802a6f8d4fc093efa1d3ee732daf767d0df44';prefix=sys.argv[1];assert re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]*',prefix)
OUT=SCRIPTS.parent/prefix;OUT.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('inputs',BASE/'snapshot-inputs.py');inputs=importlib.util.module_from_spec(spec);spec.loader.exec_module(inputs)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):
 with (OUT/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def snap():
 files={p for directory in [ROOT/'src',ROOT/'dist',ROOT/'tools/qa/chat-ui',SCRIPTS] for p in directory.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain=v1'],cwd=ROOT,text=True).splitlines(),'files':{str(p):sha(p) for p in sorted(files)}}
shutil.copytree(SCRIPTS,OUT/'executed-harness',ignore=shutil.ignore_patterns('__pycache__'))
before=snap();save('inputs-before.json',before);assert before['head']==EXPECTED and not before['status']
fullbefore=inputs.snapshot();save('all-inputs-before.json',fullbefore)
buildroot=BASE/'frontend-tests';build=json.loads((buildroot/'stats-build-02-after.json').read_text());buildresult=json.loads((buildroot/'stats-build-02-result.json').read_text());assert buildresult['exitCode']==0 and buildresult['inputsUnchanged']
mismatch=[name for name,h in build['files'].items() if sha(ROOT/name)!=h];assert len(build['files'])==409 and not mismatch,mismatch
prior=BASE/'browser/stats-certified-01';pr=json.loads((prior/'execution-result.json').read_text());assert pr['accepted'] and pr['headAfter']==EXPECTED
prior_inputs=json.loads((prior/'inputs-before.json').read_text());dist_prefix=str(ROOT/'dist')+'/'
prior_dist={p:h for p,h in prior_inputs['files'].items() if p.startswith(dist_prefix)};current_dist={p:h for p,h in before['files'].items() if p.startswith(dist_prefix)};assert prior_dist and prior_dist==current_dist
save('build-dist-reuse-binding.json',{'buildInputCount':409,'all409SourceHashesMatchBoundStatsBuild02':True,'buildAfter':{'path':str(buildroot/'stats-build-02-after.json'),'sha256':sha(buildroot/'stats-build-02-after.json')},'acceptedPriorDist':{'path':str(prior/'execution-result.json'),'sha256':sha(prior/'execution-result.json')},'priorInputs':{'path':str(prior/'inputs-before.json'),'sha256':sha(prior/'inputs-before.json')},'allDistPathSetsAndHashesMatch':True,'distFileCount':len(current_dist),'distFiles':current_dist})
with (OUT/'source-before.sha256').open('x') as f:f.write(''.join(h+'  '+name+'\n' for name,h in sorted(build['files'].items())))
proof=json.loads((SCRIPTS/'preservation-proof.json').read_text());assert proof['reverseExactlyThreeReplacementsRestoresEntireLegacyRunnerBytes'] and proof['incrementalFixtureByteIdentical']
command=['env','NODE_PATH=/workspace/qa-dependencies/node_modules','OVIRAPTOR_REPO_ROOT='+str(ROOT),'OVIRAPTOR_QA_OUTPUT='+str(OUT),'OVIRAPTOR_QA_CHROMIUM=/usr/bin/chromium','GITHUB_SHA='+EXPECTED,'node',str(SCRIPTS/'browser-qa.cjs')]
env={k:v for k,v in __import__('os').environ.items() if k!='OVIRAPTOR_QA_SCENARIOS'}
started=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic()
with (OUT/'browser.log').open('x') as f:r=subprocess.run(command,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
duration=round(time.monotonic()-tick,3);after=snap();save('inputs-after.json',after);fullafter=inputs.snapshot();save('all-inputs-after.json',fullafter)
changes=sorted(p for p in before['files'].keys()|after['files'].keys() if before['files'].get(p)!=after['files'].get(p))
result=json.loads((OUT/'browser-results.json').read_text()) if (OUT/'browser-results.json').is_file() else None
old=pathlib.Path('/workspace/validation/local-integration-20261015/browser/final-05/browser-results.json');baseline=json.loads(old.read_text())
checks={'beforeHeadExact':before['head']==EXPECTED,'afterHeadExact':after['head']==EXPECTED,'beforeClean':not before['status'],'afterClean':not after['status'],'allBrowserInputsUnchanged':not changes,'allRepositoryInputsUnchanged':inputs.same_inputs(fullbefore,fullafter),'all409BoundBuildInputsMatch':not mismatch,'entireDistPathSetAndHashesMatchPriorAccepted':prior_dist==current_dist,'all28OtherBodiesAssertionsPreservedAndThreeReplacementsReversible':proof['reverseExactlyThreeReplacementsRestoresEntireLegacyRunnerBytes'],'fixtureByteIdentical':proof['incrementalFixtureByteIdentical'],'all28ScenarioOccurrencesRetained':result is not None and __import__('collections').Counter(x['name'] for x in result['results'])==__import__('collections').Counter(x['name'] for x in baseline['results']),'noFilter':result is not None and result['scenarioFilter'] is None,'zeroBrowserErrorsUnknownIpcExternalFetch':result is not None and all(result['counts'][k]==0 for k in ['runtimeErrors','blockedRequests','unknownIpc','externalFetch']),'legacySourceAfterBrowserMatches':(OUT/'source-after-browser.sha256').exists() and (OUT/'source-before.sha256').read_bytes()==(OUT/'source-after-browser.sha256').read_bytes()}
record={'scope':'Independent28 baseline; only3 approved exact presentation contracts migrated with reverse-byte proof; actual current dist, strict synthetic IPC; separate from16','sourceHead':EXPECTED,'command':command,'startedAtUtc':started,'durationSeconds':duration,'exitCode':r.returncode,'headBefore':before['head'],'headAfter':after['head'],'browserInputCount':len(before['files']),'changedInputs':changes,'inputComparisons':inputs.compare(fullbefore,fullafter),'checks':checks,'counts':result['counts'] if result else None,'accepted':r.returncode==0 and result is not None and result['counts']['passed']==28 and result['counts']['failed']==0 and all(checks.values()),'browserLogSha256':sha(OUT/'browser.log'),'runnerSha256':sha(pathlib.Path(__file__)),'baselineResults':{'path':str(old),'sha256':sha(old)}}
save('execution-result.json',record);print(json.dumps(record));sys.exit(r.returncode or int(not record['accepted']))
