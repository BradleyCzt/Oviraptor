// Browser-only in-memory IPC contract. This is not a Tauri runtime or SQLite implementation.
module.exports = function incrementalFixture(options={}) {
 if(!options.incremental)return;
 const qa=window.__QA__,previous=window.__TAURI_INTERNALS__.invoke;
 const clone=value=>JSON.parse(JSON.stringify(value));
 const now='2026-10-15T06:00:00Z',fingerprint='a'.repeat(64);
 const make=(id,projectId=1,changes={})=>({id,projectId,assetKey:`synthetic-${id}`,company:'Synthetic QA company',host:`asset-${id}.example.invalid`,link:`https://asset-${id}.example.invalid/page`,ip:'192.0.2.1',port:'443',protocol:'https',domain:'example.invalid',title:'Unwanted welcome page',statusCode:'200',probeOutcome:'web_alive',probeEntryState:'browser',reviewTier:'P1_web',contentCategory:'business',score:'80',decision:'pending',note:'',ownershipStatus:'unreviewed',ownershipConfidence:0,authorizationStatus:'unknown',exposureEligible:false,ownershipSource:'',ownershipReason:'',isDeleted:false,firstSeen:now,lastSeen:now,lastAlive:now,extra:{probe_response_fingerprint:fingerprint,probe_body_complete:'true',probe_body_truncated:'false',body_sha256:'b'.repeat(64)},sentinelStatus:'not_sent',sentinelScanCount:0,projectFirstSeen:now,projectLastSeen:now,projectName:projectId===1?'Atlas · Synthetic workspace':'Boreal · Separate workspace',hasLogin:0,hasRegister:0,entryOpenedAt:null,...changes});
 const rows=Array.from({length:52},(_,i)=>make(101+i));
 if(options.isolationProtected)rows[2].note='Synthetic manual decision must remain protected';
 rows.push(make(153,1,{title:'Trusted portal',statusCode:'403',reviewTier:'P2_restricted',probeOutcome:'web_restricted',hasLogin:1,extra:{...rows[0].extra,probe_response_fingerprint:'c'.repeat(64)}}));
 rows.push(make(201,2,{title:'Other workspace unwanted welcome page',statusCode:'503',reviewTier:'P1_web'}));
 if(options.exactCollisionOnly)rows.splice(0,rows.length,make(401),make(402),make(403,1,{entryOpenedAt:now}),make(404,1,{extra:{...make(401).extra,fixture_response_tuple:'synthetic-different-complete-response'}}),make(201,2));
 const rules=options.seedRules?[{id:701,projectId:1,kind:'title_contains',value:'Saved Atlas exclusion',enabled:true,exampleTitle:'Synthetic Atlas page'},{id:702,projectId:2,kind:'title_contains',value:'Saved Boreal exclusion',enabled:false,exampleTitle:'Synthetic Boreal page'}]:[];
 const legacyRules=[{id:801,keyword:'Legacy global exclusion',enabled:true,createdAt:now,exampleTitle:'Synthetic historical title',exampleUrl:'https://legacy.example.invalid'}];
 const interrupted=options.interrupted?{runId:901,projectId:1,profileId:1,projectName:'Atlas · Synthetic workspace',name:'Synthetic checkpoint job',pipeline:options.pipeline||'full',createdAt:now}:null;
 const runs=interrupted?[{id:901,projectId:1,profileId:1,projectName:interrupted.projectName,name:interrupted.name,pipeline:interrupted.pipeline,status:'interrupted',stage:'probe',progress:40,processed:20,total:50,outputDir:'/synthetic/job-901',error:'Synthetic interruption',createdAt:now}]:[];
 const holds={},pending=[],backups={},tokens={};let tokenId=0,nextRule=710,revision=1;
 const audit=qa.incrementalAudit={mode:'synthetic in-memory IPC only',listQueries:[],exports:[],previewRequests:[],applyRequests:[],disableRequests:[],resumeRequests:[],rowMutations:[],startupReads:0};
 qa.assetFixture={rows,rules,legacyRules,runs,holds,pending,audit,bump(){revision++},failNextResume:false,
  hold(cmd){holds[cmd]=true},release(cmd){holds[cmd]=false;for(let i=pending.length-1;i>=0;i--)if(pending[i].cmd===cmd)pending.splice(i,1)[0].resume()},
  releaseOne(cmd){const i=pending.findIndex(x=>x.cmd===cmd);if(i>=0)pending.splice(i,1)[0].resume()}
 };
 const gate=async(cmd,value)=>{const frozen=clone(value);if(holds[cmd])await new Promise(resume=>pending.push({cmd,resume}));return frozen};
 const condition=(row,c)=>{
  const raw=c.field==='entrySeen'?(row.entryOpenedAt?'1':'0'):row[c.field];const a=String(raw??'').toLowerCase(),b=String(c.value??'').toLowerCase();
  if(c.operator==='isEmpty')return !a;if(c.operator==='notEmpty')return !!a;
  if(c.operator==='gte')return Number(a)>=Number(b);if(c.operator==='lte')return Number(a)<=Number(b);
  if(c.operator==='equals')return c.field==='reviewTier'?a===b||a.startsWith(b+'_'):a===b;
  if(c.operator==='notEquals')return !(c.field==='reviewTier'?a===b||a.startsWith(b+'_'):a===b);
  if(c.operator==='contains')return a.includes(b);if(c.operator==='notContains')return !a.includes(b);if(c.operator==='startsWith')return a.startsWith(b);if(c.operator==='endsWith')return a.endsWith(b);
  throw Error('Synthetic unsupported condition: '+c.operator);
 };
 const responseTuple=row=>JSON.stringify([row.projectId,row.extra.probe_response_fingerprint,row.extra.fixture_response_tuple||'synthetic-complete-response',row.isDeleted,row.decision,row.note,row.entryOpenedAt,row.ownershipStatus,row.authorizationStatus,row.exposureEligible,row.sentinelStatus]);
 const matching=q=>{let anchor;if(q.responseFingerprint){if(!Number.isSafeInteger(q.responseRepresentativeAssetId)||q.responseRepresentativeAssetId<=0)throw Error('Synthetic exact-response member query requires a positive representative id');anchor=rows.find(row=>row.id===q.responseRepresentativeAssetId&&row.projectId===q.projectId&&row.extra.probe_response_fingerprint===q.responseFingerprint);if(!anchor)throw Error('Synthetic representative does not belong to the response group/project');}else if(q.responseRepresentativeAssetId!==undefined)throw Error('Synthetic orphan response representative id');
 return rows.filter(row=>{
  if(q.projectId&&row.projectId!==q.projectId)return false;
  if(q.deletedView==='active'&&row.isDeleted||q.deletedView==='trash'&&!row.isDeleted)return false;
  if(q.probeView==='blocked'&&row.probeOutcome!=='blocked_content')return false;
  if(q.probeView==='browser_review'&&!['web_alive','web_restricted','browser_render_required','virtual_host_required','alive_clean'].includes(row.probeOutcome))return false;
  if(q.probeOutcomeView&&q.probeOutcomeView!=='all'&&row.probeOutcome!==q.probeOutcomeView)return false;
  if(q.decisionView==='review'&&!['pending','uncertain'].includes(row.decision))return false;
  if(q.decisionView&&!['all','review'].includes(q.decisionView)&&row.decision!==q.decisionView)return false;
  if(q.hasLoginView==='yes'&&row.hasLogin!==1||q.hasLoginView==='no'&&row.hasLogin!==0)return false;
  if(q.entrySeenView==='unseen'&&row.entryOpenedAt||q.entrySeenView==='seen'&&!row.entryOpenedAt)return false;
  if(q.responseFingerprint&&(row.extra.probe_response_fingerprint!==q.responseFingerprint||responseTuple(row)!==responseTuple(anchor)))return false;
  if(q.search&&!Object.values(row).filter(x=>typeof x==='string').join(' ').toLowerCase().includes(q.search.toLowerCase()))return false;
  let selected=true;for(const [i,c] of (q.conditions||[]).entries()){const value=condition(row,c);selected=i===0?value:c.join==='or'?selected||value:selected&&value;}return selected;
 });};
 const page=q=>{
  const members=matching(q),summary={all:members.length,pending:members.filter(x=>x.decision==='pending').length,uncertain:members.filter(x=>x.decision==='uncertain').length,confirmed:members.filter(x=>x.decision==='confirmed').length,rejected:0,notApplicable:0,sentToAgent:0};
  let items=members.map(row=>clone(row));
  if(q.collapseIdenticalResponses){const groups=new Map();for(const row of items){const key=responseTuple(row);const old=groups.get(key);if(old)old.extra.response_display_group_count=String(Number(old.extra.response_display_group_count)+1);else{row.extra.response_display_group_count='1';groups.set(key,row)}}items=[...groups.values()];}
  const total=items.length,page=q.page||1,size=q.pageSize||50;
  return {items:items.slice((page-1)*size,page*size),total,memberTotal:members.length,page,pageSize:size,summary};
 };
 const ruleRows=rule=>rows.filter(row=>row.projectId===rule.projectId&&(rule.kind==='title_contains'?row.title.toLowerCase().includes(rule.value.toLowerCase()):row.extra.body_sha256===rule.value));
 const protectedRow=row=>Boolean(row.note||row.decision!=='pending'||row.ownershipStatus==='confirmed');
 const invokeSet=new Set(['dashboard_stats','list_assets','export_assets','preview_page_rule','apply_page_rule','list_page_rules','disable_page_rule','get_asset_rule_catalog','update_asset_decisions','soft_delete_asset_selections','mark_asset_entry_opened','startup_status','list_runs','resume_job','start_job','acknowledge_interrupted_run','cancel_job']);
 window.__TAURI_INTERNALS__.invoke=async(cmd,args={})=>{
  if(!invokeSet.has(cmd))return previous(cmd,args);
  qa.calls.push({cmd,args:clone(args)});
  if(cmd==='dashboard_stats'){const list=rows.filter(x=>!args.projectId||x.projectId===args.projectId);return {projectCount:qa.projects.length,assetCount:list.length,aliveCount:list.length,pendingCount:list.filter(x=>x.decision==='pending').length,newCount:0,changedCount:0,blockedCount:list.filter(x=>x.probeOutcome==='blocked_content').length,runningJobs:runs.filter(x=>['queued','running'].includes(x.status)).length};}
  if(cmd==='list_assets'){audit.listQueries.push(clone(args.query));return gate(cmd,page(args.query));}
  if(cmd==='export_assets'){const request=clone(args.request),members=matching(request.query);audit.exports.push({...request,exportedIds:members.map(row=>row.id)});qa.mutations.push({cmd,args:clone(args)});return {path:'/synthetic/exports/all-urls.csv',rows:members.length};}
  if(cmd==='get_asset_rule_catalog')return gate(cmd,{projectRules:rules,legacyRules});
  if(cmd==='list_page_rules')return gate(cmd,rules.filter(x=>x.projectId===args.projectId));
  if(cmd==='preview_page_rule'){
   const input=clone(args.input);audit.previewRequests.push(input);
   const source=rows.find(row=>row.id===input.sourceAssetId&&row.projectId===input.projectId);if(!source)throw Error('synthetic_page_rule_source_scope');
   const rule={...input,value:input.kind==='body_sha256'?source.extra.body_sha256:input.value};const matches=ruleRows(rule),token='synthetic-preview-'+(++tokenId);
   tokens[token]={rule:clone(rule),revision};return gate(cmd,{rule,matched:matches.length,eligible:matches.filter(x=>!x.isDeleted&&!protectedRow(x)).length,protected:matches.filter(protectedRow).length,alreadyIsolated:matches.filter(x=>x.isDeleted).length,sample:matches.slice(0,4).map(row=>({assetId:row.id,title:row.title,link:row.link,eligible:!row.isDeleted&&!protectedRow(row),alreadyIsolated:row.isDeleted})),previewToken:token});
  }
  if(cmd==='apply_page_rule'){
   const input=clone(args.input);audit.applyRequests.push(input);qa.mutations.push({cmd,args:clone(args)});
   const inspected=tokens[input.previewToken];if(!inspected||inspected.revision!==revision||JSON.stringify(inspected.rule)!==JSON.stringify(input.rule))throw Error('page_rule_preview_stale: Synthetic snapshot changed; preview again');
   const rule={id:nextRule++,...input.rule,enabled:true,exampleTitle:rows.find(x=>x.id===input.rule.sourceAssetId).title};rules.push(rule);const selected=ruleRows(rule),saved=[];
   for(const row of selected){if(!row.isDeleted&&!protectedRow(row)){saved.push({id:row.id,isDeleted:row.isDeleted,probeOutcome:row.probeOutcome,contentCategory:row.contentCategory});row.isDeleted=true;row.probeOutcome='blocked_content';row.contentCategory='page_rule';}}
   backups[rule.id]=saved;delete tokens[input.previewToken];revision++;return {ruleId:rule.id,isolated:saved.length,protected:selected.filter(protectedRow).length,backupPath:'/synthetic/backups/page-rule.json'};
  }
  if(cmd==='disable_page_rule'){
   audit.disableRequests.push(clone(args));qa.mutations.push({cmd,args:clone(args)});const rule=rules.find(x=>x.id===args.ruleId&&x.projectId===args.projectId);if(!rule)throw Error('synthetic_rule_scope');rule.enabled=false;let restored=0,retained=0;
   for(const saved of backups[rule.id]||[]){const row=rows.find(x=>x.id===saved.id);if(protectedRow(row)){retained++;continue;}Object.assign(row,saved);restored++;}revision++;return {restored,retained,backupPath:'/synthetic/backups/page-rule-disabled.json'};
  }
  if(cmd==='update_asset_decisions'||cmd==='soft_delete_asset_selections'){
   qa.mutations.push({cmd,args:clone(args)});audit.rowMutations.push({cmd,args:clone(args)});let changed=0;
   for(const selection of args.input.selections){const row=rows.find(x=>x.id===selection.assetId&&x.projectId===selection.projectId);if(!row)throw Error('synthetic_selection_scope');if(cmd==='update_asset_decisions'){row.decision=args.input.decision;row.note=args.input.note;}else row.isDeleted=args.input.deleted;changed++;}revision++;return changed;
  }
  if(cmd==='mark_asset_entry_opened'){const row=rows.find(x=>x.id===args.assetId&&x.projectId===args.projectId);if(!row)throw Error('synthetic_entry_scope');qa.mutations.push({cmd,args:clone(args)});row.entryOpenedAt=now;revision++;return now;}
  if(cmd==='startup_status'){audit.startupReads++;const jobs=interrupted&&runs.some(x=>x.id===901&&['interrupted','failed'].includes(x.status))?[interrupted]:[];return gate(cmd,{reminderDays:7,staleProjects:[],interruptedJobs:jobs});}
  if(cmd==='list_runs')return gate(cmd,runs.filter(x=>!args.projectId||x.projectId===args.projectId));
  if(cmd==='resume_job'){
   audit.resumeRequests.push(clone(args));qa.mutations.push({cmd,args:clone(args)});const run=runs.find(x=>x.id===args.runId);if(!run)throw Error('synthetic_resume_missing');
   if(qa.assetFixture.failNextResume){qa.assetFixture.failNextResume=false;throw Error('Synthetic resume admission failed');}
   await gate(cmd,null);run.status='queued';run.error='';return run.id;
  }
  if(cmd==='start_job'||cmd==='acknowledge_interrupted_run'){qa.mutations.push({cmd,args:clone(args)});throw Error('Synthetic native checkpoint flow must not create or acknowledge replacement jobs');}
  if(cmd==='cancel_job'){qa.mutations.push({cmd,args:clone(args)});const run=runs.find(x=>x.id===args.runId);if(run)run.status='cancel_requested';return;}
  throw Error('Synthetic incremental fixture omitted '+cmd);
 };
};
