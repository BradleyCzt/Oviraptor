#!/usr/bin/env python3
"""Read-only process/log observation; append evidence outside the worktree."""
import datetime,json,os,pathlib,re,shutil,sys
out=pathlib.Path(__file__).resolve().parent
prefix=sys.argv[1]
if not re.fullmatch('[A-Za-z0-9][A-Za-z0-9._-]*',prefix):raise SystemExit('Plain label required')
log=out/(prefix+'.log');selection=out/(prefix+'-selection.json');body=log.read_text(errors='replace') if log.exists() else ''
selected=set(json.loads(selection.read_text())['selectedNames']) if selection.exists() else set()
seen={}
for name,status in re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)(?:[, ].*)?$',body,re.M):
 if name in selected:seen[name]=status
rows=[]
for d in pathlib.Path('/proc').iterdir():
 if not d.name.isdigit():continue
 try:
  args=(d/'cmdline').read_bytes().split(b'\0');exe=pathlib.Path(args[0].decode()).name if args else ''
  if not exe.startswith('oviraptor_lib-'):continue
  raw=[x.decode(errors='replace') for x in args if x]
  if raw[1:]!=['--test-threads=8']:continue
  s=(d/'stat').read_text().split();hz=os.sysconf('SC_CLK_TCK');up=float(pathlib.Path('/proc/uptime').read_text().split()[0]);st=(d/'status').read_text().splitlines()
  rows.append({'pid':int(d.name),'elapsedSeconds':round(up-int(s[21])/hz,1),'cpuSeconds':round((int(s[13])+int(s[14]))/hz,1),'status':{k:next((x.split(':',1)[1].strip() for x in st if x.startswith(k+':')),None) for k in ['VmRSS','Threads','State']}})
 except (OSError,ValueError,IndexError):pass
value={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stage':prefix,'selectedTests':len(selected),'observedUniqueCaseLines':len(seen),'observedStatuses':{s:sum(x==s for x in seen.values()) for s in ['ok','FAILED','ignored']},'failedObservedNames':sorted(n for n,s in seen.items() if s=='FAILED'),'remainingCaseNamesCount':len(selected-set(seen)),'mainProcesses':rows,'diskFreeBytes':shutil.disk_usage(out).free,'logBytes':log.stat().st_size if log.exists() else 0,'resultExists':(out/(prefix+'-result.json')).exists(),'supervisorReceiptExists':(out/('supervisor-'+prefix+'-receipt.json')).exists(),'longRunningNotices':re.findall(r'^test (\S+) has been running for over 60 seconds$',body,re.M)[-10:]}
for n in ['memory.current','memory.max','pids.current','pids.max']:
 p=pathlib.Path('/sys/fs/cgroup')/n
 if p.exists():value[n]=p.read_text().strip()
with (out/'native-resource.jsonl').open('a') as stream:stream.write(json.dumps(value)+'\n')
print(json.dumps(value))
