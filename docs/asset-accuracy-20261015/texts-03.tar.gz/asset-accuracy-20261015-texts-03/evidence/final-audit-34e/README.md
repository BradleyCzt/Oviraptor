New read-only source34e evidence auditor. Old e5 auditor, drafts, source receipts and failures remain unchanged.

Prepared labels: check03/build03/targeted03/full02; targeted exact old356 plus broker357; full exact3828=3725+103, original7ignored. Native completion, independent supervisor and actual outer session exit are required. Missing stages remain pending; no final acceptance is fabricated. Frontend fresh34e98Node/16/28 are separately bound; no44unique claim. Frontend npm build is earlier actual execution with all409source bytes equivalent.

Draft: python3 /workspace/validation/asset-accuracy-20261015/final-audit-34e/audit-final-gates.py --draft --output /workspace/validation/asset-accuracy-20261015/final-audit-34e/final-gates-DRAFT-01.json

After actual full02 process finishes, root may request followup review and provide --full-session-receipt ACTUAL_RECEIPT. Do not use --finalize before all real gates complete. Outputs use exclusive creation.
