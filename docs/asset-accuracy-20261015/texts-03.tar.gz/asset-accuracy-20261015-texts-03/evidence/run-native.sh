#!/usr/bin/env bash
set -euo pipefail
source /workspace/validation/asset-accuracy-20261015/native-env.sh
exec python3 /workspace/validation/asset-accuracy-20261015/run-native.py "$@"
