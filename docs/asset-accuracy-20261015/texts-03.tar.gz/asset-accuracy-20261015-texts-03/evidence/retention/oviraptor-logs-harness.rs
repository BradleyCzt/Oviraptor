mod models {
    pub struct LogEntry { pub id:i64,pub run_id:Option<i64>,pub level:String,pub stage:String,pub message:String,pub created_at:String }
}
mod agent_runtime {
    pub mod store {
        use sha2::{Digest,Sha256};
pub fn stable_hash(text: &str) -> String {
    let mut hasher = Sha256::new();
    hasher.update(text.as_bytes());
    format!("{:x}", hasher.finalize())
}
    }
    #[path="/workspace/Oviraptor-asset-accuracy-20261015/src-tauri/src/agent_runtime/secrets.rs"]
    pub mod secrets;
}
#[path="/workspace/Oviraptor-asset-accuracy-20261015/src-tauri/src/log_display.rs"]
mod log_display;
#[path="/workspace/Oviraptor-asset-accuracy-20261015/src-tauri/src/asset_logs.rs"]
mod asset_logs;
