#[path="/workspace/Oviraptor-asset-accuracy-20261015/src-tauri/src/jobs/collection_retention.rs"]
mod collection_retention;
