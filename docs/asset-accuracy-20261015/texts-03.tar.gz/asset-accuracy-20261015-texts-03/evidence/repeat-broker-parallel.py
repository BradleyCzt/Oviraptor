#!/usr/bin/env python3
"""Bounded real eight-process exact diagnosis, stop further dispatch on first red."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import datetime,hashlib,json,os,subprocess,sys,time,threading
OUT=Path(__file__).resolve().parent;ROOT=Path('/workspace/Oviraptor-asset-accuracy-20261015')
BINARY=Path('/workspace/asset-accuracy-target/debug/deps/oviraptor_lib-5e2091491b89a07c');EXPECTED='fe1756c3fc8b05b72984ade9b986ac6391ada03a21bb3cd6b6446676d3c49ab3'
CASE='scanning::agent_tests::broker_checks_role_capability_revocation_expiry_and_fencing';DEST=OUT/'statistics-broker-exact-parallel-iterations-01';PRINT=threading.Lock()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,r):
 with p.open('x') as f:json.dump(r,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def one(i,batch,command):
 paths_before=set(Path('/tmp').glob('oviraptor-broker-auth-*'));log=DEST/f'iteration-{i:03}.log';begin=utc();tick=time.monotonic()
 with log.open('x') as f:run=subprocess.run(command,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
 row={'iteration':i,'batch':batch,'startedAtUtc':begin,'finishedAtUtc':utc(),'durationSeconds':round(time.monotonic()-tick,4),'actualExitCode':run.returncode,'log':str(log),'logSha256':sha(log),'newRemainingFixturePathsAtFinish':sorted(str(p) for p in set(Path('/tmp').glob('oviraptor-broker-auth-*'))-paths_before)}
 save(DEST/f'iteration-{i:03}-result.json',row)
 with PRINT:
  print(json.dumps(row),flush=True)
  if run.returncode!=0:print(log.read_text(errors='replace'),flush=True)
 return row
def main():
 assert not DEST.exists();DEST.mkdir();assert sha(BINARY)==EXPECTED
 command=['python3','tools/run_with_subreaper.py',str(BINARY),'--exact',CASE,'--test-threads=1'];started=utc();rows=[];first_failure=None
 for batch in range(1,21):
  with ThreadPoolExecutor(max_workers=8) as pool:
   pending=[pool.submit(one,(batch-1)*8+j,batch,command) for j in range(1,9)]
   for f in as_completed(pending):
    row=f.result();rows.append(row)
    if row['actualExitCode']!=0 and first_failure is None:first_failure=row['iteration']
  if first_failure is not None:break
 result={'sourceHead':'e5fed60067fc087a0fa322ee35766f624835dd40','startedAtUtc':started,'finishedAtUtc':utc(),'case':CASE,'command':command,'binarySha256Before':EXPECTED,'binarySha256After':sha(BINARY),'maxBatches':20,'maxIterations':160,'parallelProcesses':8,'actualIterationCount':len(rows),'firstFailedIterationByCompletion':first_failure,'iterations':sorted(rows,key=lambda r:r['iteration']),'stopPolicy':'No further batch after first nonzero; already launched same-batch runs allowed to complete and all exits retained.','interpretation':'Diagnosis only; repeats cannot erase original failed and aborted full.'}
 save(DEST/'repeat-result.json',result)
 return next((r['actualExitCode'] for r in rows if r['actualExitCode']!=0),0)
if __name__=='__main__':sys.exit(main())
