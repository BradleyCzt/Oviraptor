#!/usr/bin/env python3
"""Record an actual command, complete native/audit inputs and immutable evidence."""
import datetime, importlib.util, json, pathlib, re, subprocess, sys, time
ROOT=pathlib.Path('/workspace/Oviraptor-asset-accuracy-20261015')
OUT=pathlib.Path(__file__).parent
SNAPSHOT_HELPER=OUT/'snapshot-inputs.py'
spec=importlib.util.spec_from_file_location('local_input_snapshot',SNAPSHOT_HELPER)
inputs=importlib.util.module_from_spec(spec);spec.loader.exec_module(inputs)
sha=inputs.sha
snap=inputs.snapshot

def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def main():
    name,*cmd=sys.argv[1:]
    if not cmd or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]*',name) or name in {'.','..'}:
        raise ValueError('Provide a fresh plain local prefix and actual command argv')
    log=OUT/(name+'.log');result=OUT/(name+'-result.json')
    if log.exists() or list(OUT.glob(name+'-*')):
        raise RuntimeError('Use a fresh prefix; never overwrite failure evidence')
    helper_paths={path.name:path for path in [pathlib.Path(__file__),SNAPSHOT_HELPER]}
    helper_shas={key:sha(path) for key,path in helper_paths.items()}
    before=snap();before_path=OUT/(name+'-before.json');save(before_path,before)
    started=utc();tick=time.monotonic()
    with log.open('x') as stream:run=subprocess.run(cmd,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
    finished=utc();duration=time.monotonic()-tick
    after=snap();after_path=OUT/(name+'-after.json');save(after_path,after)
    changed=sorted(name for name in before['files'].keys()|after['files'].keys() if before['files'].get(name)!=after['files'].get(name))
    r={'name':name,'command':cmd,'startedAtUtc':started,'finishedAtUtc':finished,'durationSeconds':round(duration,3),'exitCode':run.returncode,
       'snapshotVersion':inputs.VERSION,'headBefore':before['head'],'headAfter':after['head'],'statusBefore':before['status'],'statusAfter':after['status'],
       'changedInputs':changed,'inputComparisons':inputs.compare(before,after),'allInputPathSetsAndHashesUnchanged':inputs.same_inputs(before,after),
       'snapshotCounts':{key:{'before':len(before[key]),'after':len(after[key])} for key in inputs.CATEGORIES},
       'auditPolicyUnchanged':before['auditPolicy']==after['auditPolicy'] and before['auditPolicySourceSha256']==after['auditPolicySourceSha256'],
       'helperSha256':helper_shas,'helpersUnchanged':all(sha(path)==helper_shas[key] for key,path in helper_paths.items()),
       'log':str(log),'logSha256':sha(log),'beforeSnapshot':before_path.name,'beforeSnapshotSha256':sha(before_path),
       'afterSnapshot':after_path.name,'afterSnapshotSha256':sha(after_path)}
    save(result,r);print(json.dumps(r));return run.returncode
if __name__=='__main__':sys.exit(main())
