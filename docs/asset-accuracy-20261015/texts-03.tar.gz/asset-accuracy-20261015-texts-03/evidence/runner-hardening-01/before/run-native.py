#!/usr/bin/env python3
"""Prepared check/build entry. Requires explicit execute, clean source and exact HEAD."""
import argparse,datetime,hashlib,json,os,pathlib,re,subprocess,sys
ROOT=pathlib.Path('/workspace/Oviraptor-asset-accuracy-20261015');OUT=pathlib.Path(__file__).parent
TARGET=pathlib.Path('/workspace/asset-accuracy-target');RECEIPT=pathlib.Path('/workspace/validation/local-integration-20261015/native-full-accepted-03-result.json')
def sha(path):
 d=hashlib.sha256()
 with path.open('rb') as stream:
  for block in iter(lambda:stream.read(1024*1024),b''):d.update(block)
 return d.hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def require(condition,message):
 if not condition:raise RuntimeError(message)
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('stage',choices=['check','build']);p.add_argument('--label',required=True);p.add_argument('--head',required=True);p.add_argument('--execute',action='store_true');a=p.parse_args()
 require(a.execute,'Prepared only. Parent must call with --execute after source freeze.')
 require(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]*',a.label) and a.label not in {'.','..'},'Use a fresh plain evidence label')
 require(os.environ.get('CARGO_TARGET_DIR')==str(TARGET),'Source this task native-env.sh; historical target is forbidden')
 require(os.environ.get('CARGO_INCREMENTAL')=='0','Incremental disabled to fit disk without touching old evidence')
 require(os.environ.get('CARGO_BUILD_JOBS')=='2','Only serial stage with two compiler jobs is reviewed')
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();status=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=ROOT,text=True)
 require(head==a.head and len(a.head)==40 and not status,'Expected exact frozen clean worktree')
 require(subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='refactor/external-asset-accuracy-20261015','Wrong branch')
 old=json.loads(RECEIPT.read_text());old_binary=pathlib.Path(old['binary']);require(sha(old_binary)==old['binarySha256'],'Previous accepted binary changed')
 if a.stage=='check':cmd=['cargo','check','--manifest-path','src-tauri/Cargo.toml','--locked','--offline','--all-targets','--jobs','2']
 else:cmd=['cargo','test','--manifest-path','src-tauri/Cargo.toml','--locked','--offline','--lib','--no-run','--message-format=json','--jobs','2']
 started=utc();command=[sys.executable,str(OUT/'run-command.py'),a.label,*cmd];outer=subprocess.run(command,cwd=ROOT)
 result_path=OUT/(a.label+'-result.json');require(result_path.exists(),'No command receipt; retain raw command failure')
 r=json.loads(result_path.read_text());checks={'actualExitZero':r['exitCode']==0,'headFrozen':r['headBefore']==r['headAfter']==head,'cleanBeforeAfter':not r['statusBefore'] and not r['statusAfter'],'allInputsUnchanged':r['allInputPathSetsAndHashesUnchanged'],'auditPolicyUnchanged':r['auditPolicyUnchanged'],'helpersUnchanged':r['helpersUnchanged'],'oldAcceptedBinaryPreserved':sha(old_binary)==old['binarySha256']}
 artifact=None
 if a.stage=='build' and r['exitCode']==0:
  artifacts=[]
  for line in pathlib.Path(r['log']).read_text(errors='replace').splitlines():
   try:item=json.loads(line)
   except ValueError:continue
   if item.get('reason')=='compiler-artifact' and item.get('target',{}).get('name')=='oviraptor_lib' and item.get('executable'):artifacts.append(item)
  checks['uniqueActualLibraryArtifact']=len(artifacts)==1
  if len(artifacts)==1:
   artifact=artifacts[0];profile=artifact['profile'];binary=pathlib.Path(artifact['executable'])
   checks['profileOpt1WithAssertions']=str(profile.get('opt_level'))=='1' and all(profile.get(k) is True for k in ['test','debug_assertions','overflow_checks'])
   checks['newWorktreeArtifact']=pathlib.Path(artifact['manifest_path'])==ROOT/'src-tauri/Cargo.toml' and binary.is_relative_to(TARGET)
   artifact={'executable':str(binary),'sha256':sha(binary),'profile':profile,'features':artifact.get('features'),'source':artifact['target']['src_path']}
 passed=outer.returncode==0 and all(checks.values());receipt={'stage':a.stage,'sourceHead':head,'startedAtUtc':started,'finishedAtUtc':utc(),'command':command,'actualCommandExitCode':r['exitCode'],'runCommandOuterExitCode':outer.returncode,'checks':checks,'accepted':passed,'artifact':artifact,'commandResult':str(result_path),'commandResultSha256':sha(result_path)}
 with (OUT/(a.label+'-entry-result.json')).open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
 print(json.dumps(receipt));return 0 if passed else (r['exitCode'] if r['exitCode'] else 1)
if __name__=='__main__':sys.exit(main())
