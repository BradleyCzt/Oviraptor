from pathlib import Path
import importlib.util,tempfile,json,copy,hashlib,datetime,subprocess
OUT=Path('/workspace/validation/asset-accuracy-20261015');HERE=OUT/'runner-hardening-01'
spec=importlib.util.spec_from_file_location('prepared_native_entry',OUT/'run-native.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
controls=[]
with tempfile.TemporaryDirectory(prefix='artifact-metadata-',dir=HERE) as tmp:
 base=Path(tmp);root=base/'worktree';target=base/'target';(root/'src-tauri/src').mkdir(parents=True);(target/'debug/deps').mkdir(parents=True)
 (root/'src-tauri/Cargo.toml').write_text('[package]\nname="metadata-only-control"\n');(root/'src-tauri/src/lib.rs').write_text('// metadata control, never compiled\n')
 binary=target/'debug/deps/metadata-control';binary.write_text('Metadata only. Never executed.\n');binary.chmod(0o700)
 sample={'manifest_path':str(root/'src-tauri/Cargo.toml'),'target':{'name':'oviraptor_lib','src_path':str(root/'src-tauri/src/lib.rs'),'test':True,'kind':['staticlib','cdylib','rlib']},'features':[],'executable':str(binary),'profile':{'opt_level':'1','test':True,'debug_assertions':True,'overflow_checks':True,'debuginfo':0}}
 def run(name,artifact,expected,root_arg=root,target_arg=target):
  checks,_=m.artifact_contract(artifact,root_arg,target_arg);actual=all(checks.values());assert actual==expected,(name,checks)
  controls.append({'name':name,'expectedAccepted':expected,'actualAccepted':actual,'failedChecks':[k for k,v in checks.items() if not v]})
 run('valid-metadata-regular-executable',sample,True)
 for name,key,value in [('wrong-kind','kind',['bin']),('wrong-target-name','name','different_lib'),('non-test-target','test',False),('wrong-source-path','src_path',str(root/'src-tauri/Cargo.toml'))]:
  a=copy.deepcopy(sample);a['target'][key]=value;run(name,a,False)
 for key,value in [('opt_level','0'),('debug_assertions',False),('overflow_checks',False),('test',False)]:
  a=copy.deepcopy(sample);a['profile'][key]=value;run('wrong-profile-'+key,a,False)
 a=copy.deepcopy(sample);a['features']=['import-tools'];run('non-default-import-tools',a,False)
 a=copy.deepcopy(sample);a['manifest_path']=str(root/'src-tauri/src/lib.rs');run('wrong-manifest',a,False)
 outside=base/'outside-executable';outside.write_text('not executed');outside.chmod(0o700)
 a=copy.deepcopy(sample);a['executable']=str(outside);run('outside-independent-target',a,False)
 link=target/'debug/deps/executable-link';link.symlink_to(binary);a=copy.deepcopy(sample);a['executable']=str(link);run('binary-symlink',a,False)
 a=copy.deepcopy(sample);a['executable']=str(target/'../outside-executable');run('lexical-parent-escape',a,False)
 target_link=base/'target-link';target_link.symlink_to(target,target_is_directory=True);a=copy.deepcopy(sample);a['executable']=str(target_link/'debug/deps/metadata-control');run('target-directory-symlink',a,False,target_arg=target_link)
 binary.chmod(0o600);run('regular-but-not-executable',sample,False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
report={'createdAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Pure Python metadata guard controls only; no Cargo, native binary, Node, or project tests invoked','count':len(controls),'positive':sum(c['actualAccepted'] for c in controls),'negative':sum(not c['actualAccepted'] for c in controls),'allExpected':True,'controls':controls,'afterSha256':{name:sha(OUT/name) for name in ['run-native.py','run-command.py','snapshot-inputs.py','native-env.sh','run-native.sh']},'beforeSha256':json.loads((HERE/'before.json').read_text())['files'],'oldAcceptedBinarySha256':sha('/workspace/accepted-target/debug/deps/oviraptor_lib-b0a12a3ada1937eb')}
assert report['oldAcceptedBinarySha256']=='3e45d49035145d33d416f5ce3a914af8535e722ed56a19d9796ae1a17355e572'
(HERE/'result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['controls','beforeSha256','afterSha256']}))
