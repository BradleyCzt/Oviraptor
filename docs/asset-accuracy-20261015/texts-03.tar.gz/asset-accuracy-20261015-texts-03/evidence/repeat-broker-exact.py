#!/usr/bin/env python3
"""At most 100 actual isolated exact iterations; stop on first real failure."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
OUT=Path(__file__).resolve().parent
ROOT=Path('/workspace/Oviraptor-asset-accuracy-20261015')
BINARY=Path('/workspace/asset-accuracy-target/debug/deps/oviraptor_lib-5e2091491b89a07c')
EXPECTED='fe1756c3fc8b05b72984ade9b986ac6391ada03a21bb3cd6b6446676d3c49ab3'
CASE='scanning::agent_tests::broker_checks_role_capability_revocation_expiry_and_fencing'
DEST=OUT/'statistics-broker-exact-repeat-iterations-01'
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,r):
 with p.open('x') as f:json.dump(r,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def main():
 assert not DEST.exists();DEST.mkdir();assert sha(BINARY)==EXPECTED
 command=['python3','tools/run_with_subreaper.py',str(BINARY),'--exact',CASE,'--test-threads=1'];started=utc();tick=time.monotonic();rows=[];first_fail=None
 for i in range(1,101):
  if time.monotonic()-tick>=60:break
  paths_before=set(Path('/tmp').glob('oviraptor-broker-auth-*'));log=DEST/f'iteration-{i:03}.log';begin=utc();t=time.monotonic()
  with log.open('x') as f:run=subprocess.run(command,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
  row={'iteration':i,'startedAtUtc':begin,'finishedAtUtc':utc(),'durationSeconds':round(time.monotonic()-t,4),'actualExitCode':run.returncode,'log':str(log),'logSha256':sha(log),'newRemainingFixturePaths':sorted(str(p) for p in set(Path('/tmp').glob('oviraptor-broker-auth-*'))-paths_before)}
  save(DEST/f'iteration-{i:03}-result.json',row);rows.append(row);print(json.dumps(row),flush=True)
  if run.returncode!=0:
   first_fail=i;print(log.read_text(errors='replace'),flush=True);break
 result={'startedAtUtc':started,'finishedAtUtc':utc(),'sourceHead':'e5fed60067fc087a0fa322ee35766f624835dd40','case':CASE,'command':command,'binarySha256Before':EXPECTED,'binarySha256After':sha(BINARY),'maxIterations':100,'wallTimeBudgetSeconds':60,'actualIterationCount':len(rows),'firstFailedIteration':first_fail,'iterations':rows,'acceptedAsRegressionFix':False,'interpretation':'Diagnosis only; passing repeats do not erase aborted full failure.'}
 save(DEST/'repeat-result.json',result);return next((r['actualExitCode'] for r in rows if r['actualExitCode']!=0),0)
if __name__=='__main__':sys.exit(main())
