"""Exact prior accepted Rust case/summary parser; no execution on import."""
import collections,re

SUMMARY = re.compile(
    r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; '
    r'(\d+) measured; (\d+) filtered out; finished in ([\d.]+)s$', re.M
)
CASE = re.compile(r'^test (\S+) \.\.\. (ok|FAILED|ignored)(?:,.*)?\s*$', re.M)


def parse_full_log(text, listed):
    # Child stdout from a failed self-exec test is printed inside failures:.
    # Only the outer runner's initial case lines count, never nested child rows.
    header = text.split('\nfailures:\n', 1)[0]
    cases = [{'name': name, 'status': status} for name, status in CASE.findall(header)]
    counts = collections.Counter(row['name'] for row in cases)
    matches = SUMMARY.findall(text)
    summary = None
    if matches:
        state, passed, failed, ignored, measured, filtered, duration = matches[-1]
        summary = {'state': state, 'passed': int(passed), 'failed': int(failed),
                   'ignored': int(ignored), 'measured': int(measured),
                   'filteredOut': int(filtered), 'durationSeconds': float(duration)}
    return {
        'caseResults': cases,
        'completedCases': len(cases),
        'uniqueCaseNames': len(counts),
        'duplicateCaseNames': sorted(name for name, count in counts.items() if count != 1),
        'missingCaseNames': sorted(set(listed) - counts.keys()),
        'unexpectedCaseNames': sorted(counts.keys() - set(listed)),
        'exactListedCaseSet': set(listed) == counts.keys() and len(cases) == len(listed)
            and all(count == 1 for count in counts.values()),
        'passedCaseNames': [row['name'] for row in cases if row['status'] == 'ok'],
        'failedCaseNames': [row['name'] for row in cases if row['status'] == 'FAILED'],
        'ignoredCaseNames': [row['name'] for row in cases if row['status'] == 'ignored'],
        'summary': summary,
        'summaryMatchesCaseCounts': bool(summary) and
            summary['passed'] == sum(row['status'] == 'ok' for row in cases) and
            summary['failed'] == sum(row['status'] == 'FAILED' for row in cases) and
            summary['ignored'] == sum(row['status'] == 'ignored' for row in cases),
        'subreaperOrphansReaped': [int(x) for x in re.findall(
            r'^subreaper: reaped (\d+) orphan descendants$', text, re.M)],
    }

