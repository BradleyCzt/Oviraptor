#!/usr/bin/env python3
"""Record targeted frontend checks; never treat mutable native WIP as accepted."""
import datetime, hashlib, json, pathlib, re, subprocess, sys, time
ROOT=pathlib.Path('/workspace/Oviraptor-asset-accuracy-20261015')
OUT=pathlib.Path(__file__).parent
COMMANDS={
 'build': ['npm','run','build'],
 'existing': ['node','--test','--test-reporter=tap','--test-concurrency=1','tools/test_asset_workspace_review.cjs','tools/test_plugin_workspaces.cjs','tools/test_module_navigation.cjs'],
}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
 with p.open('x') as f: json.dump(v,f,indent=2); f.write('\n')
def snapshot():
 files=set(ROOT.glob('src/**/*.ts'))|set(ROOT.glob('src/**/*.vue'))|set(ROOT.glob('src/**/*.css'))|set(ROOT.glob('tools/*.cjs'))|set(ROOT.glob('tsconfig*.json'))
 for name in ['package.json','package-lock.json','yarn.lock','vite.config.ts','index.html']:
  p=ROOT/name
  if p.is_file(): files.add(p)
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(), 'files':{str(p.relative_to(ROOT)):sha(p) for p in sorted(files)}}
kind,prefix=sys.argv[1:]
assert kind in COMMANDS and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]*',prefix)
if list(OUT.glob(prefix+'*')): raise RuntimeError('Refuse existing prefix')
before=snapshot(); save(OUT/(prefix+'-before.json'),before)
started=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic();log=OUT/(prefix+'.log')
with log.open('x') as f: result=subprocess.run(COMMANDS[kind],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
duration=round(time.monotonic()-tick,3);after=snapshot();save(OUT/(prefix+'-after.json'),after)
changes=sorted(n for n in before['files'].keys()|after['files'].keys() if before['files'].get(n)!=after['files'].get(n))
counts={k:int(v) for k,v in re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)$',log.read_text(),re.M)}
record={'scope':'targeted frontend check; conservative all frontend/tools input superset; excludes native WIP acceptance','command':COMMANDS[kind],'cwd':str(ROOT),'startedAtUtc':started,'durationSeconds':duration,'exitCode':result.returncode,'counts':counts,'headBefore':before['head'],'headAfter':after['head'],'inputCount':len(before['files']),'changedInputs':changes,'inputsUnchanged':not changes,'log':str(log),'logSha256':sha(log),'runnerSha256':sha(pathlib.Path(__file__))}
save(OUT/(prefix+'-result.json'),record);print(json.dumps(record));sys.exit(result.returncode)
