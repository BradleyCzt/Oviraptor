#!/usr/bin/env python3
"""Run only the asset-accuracy SFC suite and retain its actual inputs/results."""
import datetime
import hashlib
import json
import pathlib
import re
import subprocess
import sys
import time

ROOT = pathlib.Path('/workspace/Oviraptor-asset-accuracy-20261015')
OUT = pathlib.Path(__file__).parent
COMMAND = ['node', '--test', '--test-reporter=tap', '--test-concurrency=1', 'tools/test_asset_accuracy_ui.cjs']

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot():
    # Conservative superset of every frontend source imported by the real SFC harness.
    files = set(ROOT.glob('src/**/*.ts')) | set(ROOT.glob('src/**/*.vue')) | set(ROOT.glob('src/**/*.css'))
    for relative in ['tools/test_asset_accuracy_ui.cjs', 'tools/asset_accuracy_ui_harness.cjs', 'package.json', 'package-lock.json',
                     'src/features/configuration/types.ts', 'src/features/workspaces/types.ts', 'src/i18n.ts',
                     'yarn.lock', 'tsconfig.json', 'vite.config.ts', 'index.html']:
        path = ROOT / relative
        if path.is_file():
            files.add(path)
    return {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
            'status': subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=ROOT, text=True).splitlines(),
            'files': {str(path.relative_to(ROOT)): sha(path) for path in sorted(files)}}

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def main():
    prefix = sys.argv[1]
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]*', prefix):
        raise ValueError('Use a fresh plain prefix')
    OUT.mkdir(parents=True, exist_ok=True)
    if list(OUT.glob(prefix + '*')):
        raise RuntimeError('Never overwrite earlier failure evidence')
    before = snapshot()
    save(OUT / (prefix + '-before.json'), before)
    log = OUT / (prefix + '.log')
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    tick = time.monotonic()
    with log.open('x') as stream:
        result = subprocess.run(COMMAND, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
    duration = round(time.monotonic() - tick, 3)
    after = snapshot()
    save(OUT / (prefix + '-after.json'), after)
    changes = sorted(name for name in before['files'].keys() | after['files'].keys()
                     if before['files'].get(name) != after['files'].get(name))
    counts = {key: int(value) for key, value in re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)$', log.read_text(), re.M)}
    record = {'scope': 'focused real SFC rendering with synthetic local IPC; not full acceptance',
              'inputScope': 'all src TS/Vue/CSS plus named harness/package/build configuration; conservative source superset, no native acceptance',
              'command': COMMAND, 'cwd': str(ROOT), 'startedAtUtc': started, 'durationSeconds': duration,
              'exitCode': result.returncode, 'counts': counts, 'headBefore': before['head'], 'headAfter': after['head'],
              'inputCountBefore': len(before['files']), 'inputCountAfter': len(after['files']),
              'changedInputs': changes, 'inputsUnchanged': not changes,
              'log': str(log), 'logSha256': sha(log), 'runnerSha256': sha(pathlib.Path(__file__))}
    save(OUT / (prefix + '-result.json'), record)
    print(json.dumps(record))
    return result.returncode

if __name__ == '__main__':
    sys.exit(main())
