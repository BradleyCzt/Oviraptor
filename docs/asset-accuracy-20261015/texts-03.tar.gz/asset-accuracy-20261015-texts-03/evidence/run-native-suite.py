#!/usr/bin/env python3
"""Strict actual-list targeted/full runs; never Cargo or implicit execution."""
import argparse,datetime,importlib.util,json,os,pathlib,re,shutil,subprocess,sys,time
ROOT=pathlib.Path('/workspace/Oviraptor-asset-accuracy-20261015');OUT=pathlib.Path(__file__).parent
BASELINE=pathlib.Path('/workspace/validation/local-integration-20261015/native-full-accepted-03-result.json')
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
helpers=module('accuracy_recorded_command',OUT/'run-command.py');entry=module('accuracy_artifact_contract',OUT/'run-native.py');parser=module('accuracy_native_results',OUT/'native-results.py')
sha=helpers.sha
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def require(value,message):
 if not value:raise RuntimeError(message)
def save(path,value):
 with path.open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')
def read(path):return json.loads(path.read_text())
def validate_build(prefix,head):
 result_path=OUT/(prefix+'-result.json');entry_path=OUT/(prefix+'-entry-result.json');r=read(result_path);e=read(entry_path)
 require(e['accepted'] is True and all(e['checks'].values()) and r['exitCode']==0,'Actual no-run and strict entry must pass')
 require(e['sourceHead']==r['headBefore']==r['headAfter']==head and not r['statusBefore'] and not r['statusAfter'],'Wrong/dirty build source')
 require(e['commandResult']==str(result_path) and e['commandResultSha256']==sha(result_path),'Build receipt changed')
 require(r['allInputPathSetsAndHashesUnchanged'] and r['helpersUnchanged'] and r['auditPolicyUnchanged'],'Build input/policy/helper drift')
 require(all(arg in r['command'] for arg in ['test','--locked','--offline','--lib','--no-run','--message-format=json']),'Wrong build command')
 require(not any(arg in {'--features','--all-features','--no-default-features','--release','--profile'} or arg.startswith(('--features=','--profile=')) for arg in r['command']),'Default-feature test build only')
 require(all(r['helperSha256'][n]==sha(OUT/n) for n in ['run-command.py','snapshot-inputs.py']),'Build helpers changed')
 log=OUT/(prefix+'.log');require(r['log']==str(log) and r['logSha256']==sha(log),'Build raw log changed')
 before=OUT/r['beforeSnapshot'];after=OUT/r['afterSnapshot'];require(sha(before)==r['beforeSnapshotSha256'] and sha(after)==r['afterSnapshotSha256'],'Build snapshots changed')
 require(helpers.inputs.same_inputs(read(before),read(after)),'Build snapshot path/hash mismatch')
 artifacts=[]
 for line in log.read_text(errors='replace').splitlines():
  try:item=json.loads(line)
  except ValueError:continue
  if item.get('reason')=='compiler-artifact' and item.get('target',{}).get('name')=='oviraptor_lib' and item.get('executable'):artifacts.append(item)
 require(len(artifacts)==1,'Exactly one actual executable library artifact required')
 checks,artifact=entry.artifact_contract(artifacts[0]);require(all(checks.values()),'Actual artifact contract failed: '+str(checks))
 require(artifact==e['artifact'],'Actual artifact differs from accepted build receipt')
 return r,read(after),artifact,result_path,log
PREFIXES=['jobs::','commands::ownership::','commands::assets::','commands::asset_rule_catalog::','commands::asset_export::','page_isolation::','local_incremental_ipc_tests::','conversations::']
GUARDS=['scanning::tests::implicit_history_import_commands_are_not_registered','scanning::agent_tests::retirement_literal_allowlist_matches_reviewed_sources_and_packaged_inputs','scanning::agent_tests::strix_residual_baseline_matches_the_source_exactly']
REQUIRED_FILES={
 'src-tauri/src/assets/statistics_tests.rs':'commands::assets::statistics::tests::',
 'src-tauri/src/conversations/asset_statistics_tests.rs':'conversations::reply::agent_tests::asset_statistics_tests::',
 'src-tauri/src/jobs/asset_observation_tests.rs':'jobs::asset_import_tests::asset_observation_tests::',
 'src-tauri/src/commands/asset_ownership_accuracy_tests.rs':'commands::ownership::asset_ownership_accuracy_tests::',
 'src-tauri/src/jobs/collection_retention_tests.rs':'jobs::collection_retention::tests::',
 'src-tauri/src/jobs/collection_summary.rs':'jobs::collection_summary::tests::',
 'src-tauri/src/jobs/native_collection_resume_tests.rs':'jobs::native_workers::native_collection_resume_tests::',
 'src-tauri/src/jobs/native_discovery_tests.rs':'jobs::native_workers::discovery_tests::',
 'src-tauri/src/jobs/asset_identity.rs':'jobs::asset_identity::tests::',
}
def list_cases(binary,prefix,ignored=False):
 command=[str(binary),*(['--ignored'] if ignored else []),'--list'];started=utc();r=subprocess.run(command,cwd=ROOT,text=True,capture_output=True)
 tag='ignored-list' if ignored else 'list';path=OUT/(prefix+'-'+tag+'.txt');path.write_text(r.stdout);(OUT/(prefix+'-'+tag+'-stderr.txt')).write_text(r.stderr)
 names=re.findall(r'^(\S+): test$',r.stdout,re.M);summary=re.findall(r'^(\d+) tests, (\d+) benchmarks$',r.stdout,re.M)
 save(OUT/(prefix+'-'+tag+'-result.json'),{'command':command,'startedAtUtc':started,'finishedAtUtc':utc(),'exitCode':r.returncode,'names':names,'count':len(names),'summary':summary,'stdoutSha256':sha(path)})
 require(r.returncode==0 and names and len(names)==len(set(names)) and summary==[(str(len(names)),'0')],'Actual nonzero unique --list failed')
 return names
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('build_prefix');p.add_argument('prefix');p.add_argument('--head',required=True);p.add_argument('--mode',choices=['targeted','full'],required=True);p.add_argument('--execute',action='store_true');a=p.parse_args()
 require(a.execute,'Explicit parent --execute only')
 require(all(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]*',n) and n not in {'.','..'} for n in [a.prefix,a.build_prefix]),'Invalid label')
 require(not list(OUT.glob(a.prefix+'*')),'Use a fresh result prefix; never replace failure history')
 save(OUT/(a.prefix+'-reservation.json'),{'utc':utc(),'mode':a.mode,'build':a.build_prefix,'pid':os.getpid()})
 completed=None;finished=None;after=None;selected=[];artifact=None
 try:
  helper_paths={p.name:p for p in [pathlib.Path(__file__),OUT/'run-native.py',OUT/'run-command.py',OUT/'snapshot-inputs.py',OUT/'native-results.py',OUT/'audit-policy.json']};helper_shas={n:sha(p) for n,p in helper_paths.items()}
  build,build_inputs,artifact,build_path,build_log=validate_build(a.build_prefix,a.head);binary=pathlib.Path(artifact['executable']);binary_sha=artifact['sha256']
  baseline_sha=sha(BASELINE);old=read(BASELINE);old_names={r['name'] for r in old['caseResults']};old_ignored=sorted(old['ignoredCaseNames']);old_binary=pathlib.Path(old['binary'])
  require(old['accepted'] is True and all(old['checks'].values()) and old['sourceHead']=='24179702c9d163e1d21bf9a23c4528589355166a' and len(old_names)==old['listedTests']==3725,'Invalid old full03 accepted ledger')
  require(old['commandExitCode']==0 and old['summary']=={'state':'ok','passed':3718,'failed':0,'ignored':7,'measured':0,'filteredOut':0,'durationSeconds':1595.82},'Wrong original accepted outcome')
  require(sha(old_binary)==old['binarySha256'],'Old accepted binary changed')
  before=helpers.snap();save(OUT/(a.prefix+'-before.json'),before)
  require(before['head']==a.head==build_inputs['head'] and not before['status'] and helpers.inputs.same_inputs(before,build_inputs),'Current clean source must exactly match build input sets/hashes')
  names=list_cases(binary,a.prefix);ignored=list_cases(binary,a.prefix,True)
  migration={'baseline':str(BASELINE),'baselineSha256':baseline_sha,'oldCount':len(old_names),'currentCount':len(names),'preservedNamed':len(old_names & set(names)),'removed':sorted(old_names-set(names)),'added':sorted(set(names)-old_names),'ignoredNames':ignored,'expectedOriginalIgnoredNames':old_ignored}
  save(OUT/(a.prefix+'-migration.json'),migration)
  require(not migration['removed'] and migration['preservedNamed']==3725,'A prior case was removed/renamed; semantic review required before running, never silently skipped')
  require(sorted(ignored)==old_ignored and len(ignored)==7,'Original ignored identities changed')
  required=[];domain_counts={}
  for file,prefix in REQUIRED_FILES.items():
   declarations=re.findall(r'#\[test\]\s*(?:#\[[^\n]*\]\s*)*fn\s+(\w+)',(ROOT/file).read_text());require(declarations,'Expected nonzero source declarations: '+file)
   exact=[prefix+n for n in declarations];require(set(exact)<=set(names),'Declared affected case missing from actual compiled list: '+str(set(exact)-set(names)));required+=exact;domain_counts[prefix]=len(exact)
  require(set(GUARDS)<=set(names),'Actual source guards missing')
  selected=names if a.mode=='full' else [n for n in names if any(n.startswith(p) for p in PREFIXES) or n in GUARDS or n in migration['added']]
  require(selected and len(selected)==len(set(selected)) and set(required+GUARDS)<=set(selected),'Zero/duplicate/incomplete actual selection')
  for prefix in PREFIXES:require(any(n.startswith(prefix) for n in selected),'Zero-case affected cohort: '+prefix)
  expected_ignored=sorted(set(ignored)&set(selected));threads=8 if a.mode=='full' else 4
  selection={'mode':a.mode,'totalListed':len(names),'selectedCount':len(selected),'selectedNames':selected,'expectedIgnoredNames':expected_ignored,'requiredSourceDomains':domain_counts,'requiredDeclaredNames':required,'allNewlyCompiledNamesIncluded':set(migration['added'])<=set(selected),'caseMigration':migration}
  save(OUT/(a.prefix+'-selection.json'),selection)
  pre=helpers.snap();save(OUT/(a.prefix+'-pre-run.json'),pre);require(pre['head']==before['head'] and not pre['status'] and helpers.inputs.same_inputs(pre,before),'Source changed during list/preflight')
  require(sha(binary)==binary_sha and all(sha(p)==helper_shas[n] for n,p in helper_paths.items()),'Binary/helper changed before run')
  command=['python3','tools/run_with_subreaper.py',str(binary),*(['--exact',*selected] if a.mode=='targeted' else []),f'--test-threads={threads}']
  save(OUT/(a.prefix+'-command.json'),{'sourceHead':a.head,'command':command,'binary':artifact,'buildResult':str(build_path),'buildResultSha256':sha(build_path),'buildLog':str(build_log),'buildLogSha256':sha(build_log),'helperSha256':helper_shas,'featuresScope':'default-feature application library only; no real desktop or release package'})
  execution_env={key:os.environ.get(key) for key in ['OVIRAPTOR_TEST_NO_SANDBOX','CHROME_BINARY','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_PROFILE_TEST_OPT_LEVEL','CARGO_PROFILE_TEST_DEBUG_ASSERTIONS','CARGO_PROFILE_TEST_OVERFLOW_CHECKS','OVIRAPTOR_NATIVE_SYSROOT']}
  require(execution_env['OVIRAPTOR_TEST_NO_SANDBOX']=='1' and execution_env['CHROME_BINARY']=='/usr/bin/chromium','Approved unprivileged Chromium CI environment must be explicit')
  save(OUT/(a.prefix+'-execution-environment.json'),{'recordedAtUtc':utc(),'explicitEnvironment':execution_env,'noCredentialsRecorded':True})
  started=utc();tick=time.monotonic();disk_before=shutil.disk_usage(ROOT)
  with (OUT/(a.prefix+'.log')).open('x') as stream:completed=subprocess.run(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
  finished=utc();duration=time.monotonic()-tick;disk_after=shutil.disk_usage(ROOT);after=helpers.snap();save(OUT/(a.prefix+'-after.json'),after)
  parsed=parser.parse_full_log((OUT/(a.prefix+'.log')).read_text(errors='replace'),selected);summary=parsed['summary'];expected_filtered=len(names)-len(selected)
  checks={'actualCommandExitZero':completed.returncode==0,'sameCleanFrozenHead':before['head']==after['head']==a.head and not before['status'] and not after['status'],'allInputSetsAndHashesUnchanged':helpers.inputs.same_inputs(before,after),'auditPolicyUnchanged':before['auditPolicy']==after['auditPolicy'] and before['auditPolicySourceSha256']==after['auditPolicySourceSha256'],'binaryUnchanged':binary.is_file() and not binary.is_symlink() and sha(binary)==binary_sha,'helpersUnchanged':all(sha(p)==helper_shas[n] for n,p in helper_paths.items()),'everyNewCompiledCaseIncluded':set(migration['added'])<=set(selected),'allPrior3725NamesPreserved':migration['preservedNamed']==3725 and not migration['removed'],'oldFull03ResultUnchanged':sha(BASELINE)==baseline_sha,'oldFull03BinaryUnchanged':sha(old_binary)==old['binarySha256'],'everySelectedCaseExactlyOnce':parsed['exactListedCaseSet'],'summaryMatchesCases':parsed['summaryMatchesCaseCounts'],'onlyExpectedOriginalIgnored':sorted(parsed['ignoredCaseNames'])==expected_ignored,'summaryExpectedPassFailIgnoreFilter':bool(summary) and summary['state']=='ok' and summary['passed']==len(selected)-len(expected_ignored) and summary['failed']==summary['measured']==0 and summary['ignored']==len(expected_ignored) and summary['filteredOut']==expected_filtered,'postSnapshotAfterFinished':after['utc']>finished}
  result={'sourceHead':a.head,'mode':a.mode,'command':command,'commandExitCode':completed.returncode,'startedAtUtc':started,'finishedAtUtc':finished,'durationSeconds':round(duration,3),'binary':str(binary),'binarySha256':binary_sha,'profile':artifact['profile'],'listedTests':len(names),'selectedTests':len(selected),'expectedOriginalIgnoredNames':old_ignored,'selectedExpectedIgnoredNames':expected_ignored,'executionEnvironment':execution_env,'inputComparisons':helpers.inputs.compare(before,after),'beforeSnapshotSha256':sha(OUT/(a.prefix+'-before.json')),'afterSnapshotSha256':sha(OUT/(a.prefix+'-after.json')),'helperSha256':helper_shas,'checks':checks,'accepted':all(checks.values()),'logSha256':sha(OUT/(a.prefix+'.log')),'disk':{'before':dict(zip(['total','used','free'],disk_before)),'after':dict(zip(['total','used','free'],disk_after))},**parsed}
  save(OUT/(a.prefix+'-result.json'),result);exit_code=completed.returncode or (0 if result['accepted'] else 1)
  save(OUT/(a.prefix+'-outer-receipt.json'),{'recordedAtUtc':utc(),'actualCommandExitCode':completed.returncode,'scriptExitCode':exit_code,'accepted':result['accepted'],'resultSha256':sha(OUT/(a.prefix+'-result.json'))})
  print(json.dumps({'mode':a.mode,'accepted':result['accepted'],'commandExitCode':completed.returncode,'summary':summary,'failedCases':parsed['failedCaseNames'],'checks':checks,'result':str(OUT/(a.prefix+'-result.json'))}));return exit_code
 except Exception as error:
  save(OUT/(a.prefix+'-collection-error.json'),{'utc':utc(),'errorType':type(error).__name__,'error':str(error),'accepted':False,'nativeExecutionStarted':completed is not None or finished is not None,'actualCommandExitCode':completed.returncode if completed else None,'postSnapshotRecorded':after is not None});raise
if __name__=='__main__':sys.exit(main())
