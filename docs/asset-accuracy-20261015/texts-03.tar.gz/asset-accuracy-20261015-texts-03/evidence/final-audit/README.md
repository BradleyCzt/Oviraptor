# Prepared independent gate auditor

This folder is outside the repository. The auditor reads evidence and creates a fresh index only here; it never runs Cargo, Node, Chromium, a model, or a scan. It does run read-only Git metadata and the reviewed complete source-input snapshot walk.

The fixed source is e5fed60067fc087a0fa322ee35766f624835dd40. The prepared contract pins original3725 names, the103 actually compiled additions, the original7 ignored cases, runner/helper identities and frontend baseline sets. It reports Node98files/1662occurrences separately from Browser16 and Browser28; it does not claim44 unique scenarios.

Draft command (choose a fresh output filename):

    python3 /workspace/validation/asset-accuracy-20261015/final-audit/audit-final-gates.py --draft --output /workspace/validation/asset-accuracy-20261015/final-audit/final-gates-DRAFT-next.json

`--finalize` refuses if any gate is pending or failed, writes a new `.refusal.json`, and does not create the requested final output. Do not use it before parent review and actual completion. Full session completion is a separate required receipt, supplied with `--full-session-receipt /absolute/path.json`:

```json
{
  "sourceHead": "e5fed60067fc087a0fa322ee35766f624835dd40",
  "actualProcessExitCode": null,
  "sessionId": "actual tool session identity",
  "finishedAtUtc": null,
  "resultSha256": null
}
```

The null values above are schema examples, never acceptance. Populate them only from an actually completed tool session. The independently observed supervisor receipt is validated separately, including its real subprocess return, SHA bindings and unchanged runner.

Actual preparation outcome: DRAFT01 observed native full pending. By DRAFT02/03, full01 had ended with command/supervisor143, no full footer and one observed failing broker-expiry case. It is an interrupted partial run, not a completed failed suite or accepted full regression. Finalization of this full01 is deliberately blocked. Any new source or renamed rerun requires a reviewed new binding/version; do not edit old evidence or silently repoint the existing contract.

All earlier failed Node/browser/native attempts are retained and indexed with their actual nonzero exit fields. The frontend production bundle was built at recorded earlier HEAD7ff60de, then all409 exact frontend/build input paths+SHA and actual loaded dist bytes were matched to current source; this is explicitly source-byte-equivalent reuse, not an npm build performed at e5.

Preserved drafts and prior audit script snapshots are historical. No final index was generated during preparation.
