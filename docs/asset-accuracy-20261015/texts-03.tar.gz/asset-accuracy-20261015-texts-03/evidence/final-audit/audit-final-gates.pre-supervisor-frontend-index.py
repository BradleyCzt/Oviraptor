#!/usr/bin/env python3
"""Read completed evidence only. Draft is never final acceptance; missing gates fail closed."""
import argparse, collections, datetime, hashlib, importlib.util, json, os, pathlib, re, subprocess, sys
ROOT=pathlib.Path('/workspace/Oviraptor-asset-accuracy-20261015')
BASE=pathlib.Path('/workspace/validation/asset-accuracy-20261015')
HERE=pathlib.Path(__file__).parent
CONTRACT_SHA='48338235dc3ab9d32fa96bdd13a79b58a371d1ffa98496095d0f2ec9fef53f1e'
CATEGORIES=['nativeInputs','auditInputs','trackedInputs','untrackedInputs','files']
class Pending(Exception):pass
def need(value,message):
    if not value:raise ValueError(message)
def exact_int(value,expected=None):return type(value) is int and (expected is None or value==expected)
def true(value):return type(value) is bool and value is True
def all_true(checks):return type(checks) is dict and bool(checks) and all(true(x) for x in checks.values())
def sha(path):
    result=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):result.update(block)
    return result.hexdigest()
def stamp(value):return datetime.datetime.fromisoformat(value.replace('Z','+00:00')).astimezone(datetime.timezone.utc)
def write_new(path,value):
    with path.open('x') as stream:json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')
class Audit:
    def __init__(self,contract):self.contract=contract;self.head=contract['sourceHead'];self.refs={};self.current=None;self.binary=None;self.results={}
    def ref(self,path,expected=None):
        path=pathlib.Path(path)
        if not path.is_absolute():path=BASE/path
        if not path.exists():raise Pending('Not completed/present: '+str(path))
        need(not path.is_symlink() and path.is_file(),'Evidence must be a regular file: '+str(path))
        digest=sha(path);need(expected is None or digest==expected,'Evidence SHA mismatch: '+str(path))
        item={'relativePath':os.path.relpath(path,BASE),'sha256':digest,'bytes':path.stat().st_size}
        self.refs[str(path)]=item;return item
    def read(self,path,expected=None):self.ref(path,expected);return json.loads((path if pathlib.Path(path).is_absolute() else BASE/pathlib.Path(path)).read_text())
    def text(self,path,expected=None):self.ref(path,expected);return (path if pathlib.Path(path).is_absolute() else BASE/pathlib.Path(path)).read_text(errors='replace')
    def referenced(self,record):return self.ref(pathlib.Path(record['path']),record['sha256'])
    def snapshot_pair(self,before,after):
        need(before['head']==after['head']==self.head and before['status']==after['status']==[],'Wrong/dirty snapshots')
        for category in CATEGORIES:
            need(type(before[category]) is dict and before[category]==after[category],category+' changed')
            need(self.current is not None and after[category]==self.current[category],category+' differs from current complete input set')
        for key in ['snapshotVersion','auditPolicy','auditPolicyReferenceSha256','auditPolicySourceSha256']:
            need(before[key]==after[key]==self.current[key],'Audit policy/version drift: '+key)
    def source(self):
        head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
        status=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=ROOT,text=True)
        need(head==self.head and not status,'Require exact current frozen clean code HEAD before docs publication')
        for name,digest in self.contract['fixedHelpers'].items():self.ref(BASE/name,digest)
        spec=importlib.util.spec_from_file_location('independent_final_snapshot',BASE/'snapshot-inputs.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        # Read-only policy walk and Git metadata; no application/test command.
        self.current=module.snapshot();need(self.current['head']==head and self.current['status']==[],'Current snapshot wrong')
        return {'sourceHead':head,'inputCounts':{k:len(self.current[k]) for k in CATEGORIES},'auditPolicySha256':self.current['auditPolicyReferenceSha256'],'command':['git','rev-parse/status; read-only complete input snapshot']}
    def command(self,prefix):
        record=self.read(BASE/(prefix+'-result.json'))
        need(exact_int(record['exitCode'],0),'Actual command failed: '+prefix)
        need(record['headBefore']==record['headAfter']==self.head and record['statusBefore']==record['statusAfter']==[],'Wrong/dirty command source')
        need(all(true(record[k]) for k in ['allInputPathSetsAndHashesUnchanged','auditPolicyUnchanged','helpersUnchanged']),'Command input/helper/policy drift')
        need(type(record['command']) is list and record['command'] and all(type(x) is str for x in record['command']),'Invalid command argv')
        self.ref(pathlib.Path(record['log']),record['logSha256'])
        before=self.read(BASE/record['beforeSnapshot'],record['beforeSnapshotSha256']);after=self.read(BASE/record['afterSnapshot'],record['afterSnapshotSha256']);self.snapshot_pair(before,after)
        need(stamp(after['utc'])>stamp(record['finishedAtUtc']),'Post-command snapshot predates completion')
        for name,digest in record['helperSha256'].items():self.ref(BASE/name,digest)
        return record
    def native_build(self,prefix,stage):
        record=self.command(prefix);entry=self.read(BASE/(prefix+'-entry-result.json'))
        need(entry['sourceHead']==self.head and true(entry['accepted']) and all_true(entry['checks']),'Strict native entry did not accept')
        need(exact_int(entry['actualCommandExitCode'],0) and exact_int(entry['runCommandOuterExitCode'],0),'Actual native wrapper failure')
        self.ref(pathlib.Path(entry['commandResult']),entry['commandResultSha256'])
        expected=['cargo','check','--manifest-path','src-tauri/Cargo.toml','--locked','--offline','--all-targets','--jobs','2'] if stage=='check' else ['cargo','test','--manifest-path','src-tauri/Cargo.toml','--locked','--offline','--lib','--no-run','--message-format=json','--jobs','2']
        need(record['command']==expected,'Unexpected native command/features/profile')
        artifact=None
        if stage=='build':
            rows=[]
            for line in pathlib.Path(record['log']).read_text(errors='replace').splitlines():
                try:value=json.loads(line)
                except ValueError:continue
                if value.get('reason')=='compiler-artifact' and value.get('target',{}).get('name')=='oviraptor_lib' and value.get('executable'):rows.append(value)
            need(len(rows)==1,'Need unique actual Cargo library executable artifact')
            artifact=rows[0];profile=artifact['profile'];target=artifact['target']
            need(str(profile['opt_level'])=='1' and all(true(profile[k]) for k in ['test','debug_assertions','overflow_checks']),'Wrong actual Cargo profile')
            need(artifact['features']==[] and target['name']=='oviraptor_lib' and true(target['test']) and set(target['kind'])=={'staticlib','cdylib','rlib'},'Wrong library/default features')
            need(artifact['manifest_path']==str(ROOT/'src-tauri/Cargo.toml') and target['src_path']==str(ROOT/'src-tauri/src/lib.rs'),'Wrong worktree Cargo artifact')
            binary=pathlib.Path(artifact['executable']);need(not binary.is_symlink() and binary.is_file() and os.access(binary,os.X_OK),'Invalid native binary')
            need(binary.resolve().is_relative_to(pathlib.Path('/workspace/asset-accuracy-target').resolve()),'Binary outside current target')
            self.binary={'path':str(binary),'sha256':sha(binary),'profile':profile,'features':[]};self.ref(binary,self.binary['sha256'])
            need(entry['artifact']['sha256']==self.binary['sha256'] and entry['artifact']['executable']==str(binary) and entry['artifact']['profile']==profile,'Build artifact receipt mismatch')
        return {'command':record['command'],'durationSeconds':record['durationSeconds'],'artifact':self.binary if artifact else None}
    def native(self,prefix,mode):
        need(self.binary is not None,'Current successful native build gate required')
        record=self.read(BASE/(prefix+'-result.json'));outer=self.read(BASE/(prefix+'-outer-receipt.json'));command=self.read(BASE/(prefix+'-command.json'))
        need(record['sourceHead']==self.head and record['mode']==mode and true(record['accepted']) and all_true(record['checks']),'Native run failed/unaccepted')
        need(exact_int(record['commandExitCode'],0) and exact_int(outer['actualCommandExitCode'],0) and exact_int(outer['scriptExitCode'],0) and true(outer['accepted']),'Native command/runner exit not zero')
        self.ref(BASE/(prefix+'-result.json'),outer['resultSha256'])
        need(record['binary']==self.binary['path'] and record['binarySha256']==self.binary['sha256'] and record['profile']==self.binary['profile'],'Native binary/profile mismatch')
        self.ref(pathlib.Path(record['binary']),record['binarySha256'])
        for name,digest in record['helperSha256'].items():self.ref(BASE/name,digest)
        need(command['sourceHead']==self.head and command['command']==record['command'] and command['helperSha256']==record['helperSha256'],'Native command receipt differs')
        baseline=self.read(pathlib.Path(self.contract['baselineNative']['path']),self.contract['baselineNative']['sha256']);need(true(baseline['accepted']) and all_true(baseline['checks']) and exact_int(baseline['listedTests'],3725),'Invalid accepted3725 baseline')
        old_names=[row['name'] for row in baseline['caseResults']];need(len(old_names)==len(set(old_names))==3725,'Baseline cases not unique')
        ignored=sorted(baseline['ignoredCaseNames']);need(len(ignored)==7,'Baseline ignore count changed')
        self.ref(pathlib.Path(baseline['binary']),baseline['binarySha256'])
        listed_text=self.text(BASE/(prefix+'-list.txt'));names=re.findall(r'^(\S+): test$',listed_text,re.M)
        need(len(names)==len(set(names))==3828 and re.findall(r'^(\d+) tests, (\d+) benchmarks$',listed_text,re.M)==[('3828','0')],'Actual list not exact3828')
        listing=self.read(BASE/(prefix+'-list-result.json'));need(exact_int(listing['exitCode'],0) and listing['names']==names,'Actual --list receipt mismatch');self.ref(BASE/(prefix+'-list.txt'),listing['stdoutSha256'])
        ignored_text=self.text(BASE/(prefix+'-ignored-list.txt'));need(sorted(re.findall(r'^(\S+): test$',ignored_text,re.M))==ignored,'Actual ignored identities changed')
        migration=self.read(BASE/(prefix+'-migration.json'));added=sorted(set(names)-set(old_names));need(not(set(old_names)-set(names)) and len(added)==103 and added==sorted(self.contract['expectedAddedNativeCases']),'Baseline3725 + reviewed103 changed')
        need(migration['removed']==[] and exact_int(migration['preservedNamed'],3725) and migration['added']==added and exact_int(migration['currentCount'],3828),'Migration ledger mismatch')
        selection=self.read(BASE/(prefix+'-selection.json'));selected=selection['selectedNames'];need(len(selected)==len(set(selected)) and set(added)<=set(selected),'Selected names omit/duplicate new cases')
        if mode=='full':need(selected==names,'Full run selection must equal actual complete list')
        else:need(len(selected)==356 and set(selection['requiredDeclaredNames'])<=set(selected),'Targeted cohort incomplete')
        expected_command=['python3','tools/run_with_subreaper.py',self.binary['path'],*(['--exact',*selected] if mode=='targeted' else []),f'--test-threads={8 if mode=="full" else 4}'];need(record['command']==expected_command,'Wrong native filters/threads/command')
        before=self.read(BASE/(prefix+'-before.json'),record['beforeSnapshotSha256']);after=self.read(BASE/(prefix+'-after.json'),record['afterSnapshotSha256']);pre=self.read(BASE/(prefix+'-pre-run.json'));self.snapshot_pair(before,after);self.snapshot_pair(before,pre);need(stamp(after['utc'])>stamp(record['finishedAtUtc']),'Native after snapshot not post-finish')
        raw=self.text(BASE/(prefix+'.log'),record['logSha256']);head=raw.split('\nfailures:\n',1)[0];rows=[{'name':n,'status':s} for n,s in re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)(?:,.*)?\s*$',head,re.M)]
        need(rows==record['caseResults'] and collections.Counter(x['name'] for x in rows)==collections.Counter(selected),'Raw case ledger is not exact once')
        summaries=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([\d.]+)s$',raw,re.M);need(len(summaries)==1,'Need one completed outer native footer')
        state,p,f,i,m,filtered,duration=summaries[0];expected_ignore=sorted(set(selected)&set(ignored));summary={'state':state,'passed':int(p),'failed':int(f),'ignored':int(i),'measured':int(m),'filteredOut':int(filtered),'durationSeconds':float(duration)}
        need(summary==record['summary'] and state=='ok' and int(p)==len(selected)-len(expected_ignore) and int(f)==int(m)==0 and int(i)==len(expected_ignore) and int(filtered)==3828-len(selected),'Native summary mismatch')
        need(sorted(row['name'] for row in rows if row['status']=='ignored')==expected_ignore and all(row['status']=='ok' for row in rows if row['name'] in added),'New cases failed/skipped or ignore drift')
        self.results[mode]=record
        return {'command':record['command'],'summary':summary,'commandDurationSeconds':record['durationSeconds'],'baselinePreservedNamed':3725,'addedUnique':103,'caseCount':len(rows),'binarySha256':record['binarySha256']}
    def observed_full_outer(self,path):
        if not path:raise Pending('Actual tool/session completion receipt is required, separate from runner self-receipt')
        need('full' in self.results,'Completed accepted full native gate required')
        r=self.read(pathlib.Path(path));full=self.results['full']
        need(r['sourceHead']==self.head and exact_int(r['actualProcessExitCode'],0),'Actual full outer process did not finish zero')
        need(type(r.get('sessionId')) in [str,int] and bool(str(r['sessionId'])),'Need actual execution session identity')
        self.ref(BASE/'statistics-native-full-01-result.json',r['resultSha256'])
        need(stamp(r['finishedAtUtc'])>=stamp(full['finishedAtUtc']),'Actual outer completion predates native completion')
        return {'receipt':self.refs[str(pathlib.Path(path))],'actualProcessExitCode':0,'sessionId':r['sessionId']}
    def frontend_build(self):
        prefix=BASE/'frontend-tests/stats-build-02';r=self.read(pathlib.Path(str(prefix)+'-result.json'));before=self.read(pathlib.Path(str(prefix)+'-before.json'));after=self.read(pathlib.Path(str(prefix)+'-after.json'))
        need(exact_int(r['exitCode'],0) and true(r['inputsUnchanged']) and r['command']==['npm','run','build'] and before['files']==after['files'],'Frontend build failed/drift')
        current=set(ROOT.glob('src/**/*.ts'))|set(ROOT.glob('src/**/*.vue'))|set(ROOT.glob('src/**/*.css'))|set(ROOT.glob('tools/*.cjs'))|set(ROOT.glob('tsconfig*.json'))
        current|={ROOT/n for n in ['package.json','package-lock.json','yarn.lock','vite.config.ts','index.html'] if (ROOT/n).is_file()}
        need(set(after['files'])=={str(p.relative_to(ROOT)) for p in current} and len(current)==409,'Frontend complete build path set changed')
        for p,digest in after['files'].items():need(sha(ROOT/p)==digest,'Frontend build source differs: '+p)
        self.ref(pathlib.Path(r['log']),r['logSha256']);return {'command':r['command'],'durationSeconds':r['durationSeconds'],'actualBuildHead':r['headAfter'],'currentSourceByteEquivalent':True,'sourceInputs':409,'note':'Actual build ran at earlier recorded HEAD; all409 source paths/bytes independently match current frozen source. Not claimed as an e5 npm rebuild.'}
    def node(self):
        r=self.command('stats-frozen-node-01');folder=BASE/'stats-frozen-node-01';s=self.read(folder/'summary.json');selection=self.read(folder/'selection.json');ledger=self.read(folder/'case-ledger.json');preserve=self.read(folder/'baseline-preservation.json');index=self.read(folder/'evidence-index.json')
        need(s['sourceHead']==self.head and true(s['accepted']) and all_true(s['checks']) and true(index['accepted']) and index['sourceHead']==self.head,'Node receipts not accepted/current')
        files=[str(p.relative_to(ROOT)) for p in sorted(ROOT.glob('tools/test_*.cjs'))];need(len(files)==98 and files==[x['path'] for x in selection['files']] and s['fileCount']==98,'Node98 selection differs')
        for x in selection['files']:need(sha(ROOT/x['path'])==x['sha256'],'Node source changed: '+x['path'])
        need(r['command']==selection['command']==s['command'] and r['command']==['env','OVIRAPTOR_TEST_NO_SANDBOX=1','CHROME_BINARY=/usr/bin/chromium','node','--test','--test-reporter=tap','--test-concurrency=1',*files],'Node command filters/selection differ')
        raw=pathlib.Path(r['log']).read_text();rows=[]
        for line in raw.splitlines():
            match=re.fullmatch(r'(ok|not ok) (\d+) - (.+)',line)
            if match:
                name=re.split(r' # (?:SKIP|TODO)\b',match[3],maxsplit=1)[0];rows.append((name,match[1],bool(re.search(r' # SKIP\b',match[3])),bool(re.search(r' # TODO\b',match[3]))))
        need(rows==[(x['name'],x['status'],x['skipped'],x['todo']) for x in ledger] and len(rows)==1662,'Node raw occurrence ledger differs')
        summary={k:int(v) for k,v in re.findall(r'^# (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)$',raw,re.M)}
        expected={'tests':1662,'suites':0,'pass':1650,'fail':0,'cancelled':0,'skipped':12,'todo':0};need(summary==expected and all(exact_int(s['summary'][k],v) for k,v in expected.items()),'Node footer count mismatch')
        baseline=self.read(pathlib.Path(self.contract['baselineNode']['path']),self.contract['baselineNode']['sha256']);old=collections.Counter(baseline['titleOccurrenceMultiset']);now=collections.Counter(x[0] for x in rows);need(sum(old.values())==1588 and not(old-now) and sum((now-old).values())==74,'Node old1588 occurrence or new74 changed')
        old_skips=collections.Counter(x['title'] for x in baseline['skippedCases']);need(old_skips==collections.Counter(x[0] for x in rows if x[2]) and sum(old_skips.values())==12,'Node original12 skips changed')
        need(true(preserve['accepted']) and all_true(preserve['checks']) and preserve['removedOccurrences']=={} and preserve['baselineSkipMultiset']==preserve['currentSkipMultiset'],'Node skip/reason/source preservation failed')
        for x in preserve['bindings']:self.referenced(x)
        for x in index['evidence']:self.referenced(x)
        return {'command':r['command'],'summary':summary,'durationSeconds':r['durationSeconds'],'baselineOccurrencesPreserved':1588,'addedOccurrences':74,'originalSkipped':12}
    def browser(self,relative,count):
        folder=BASE/relative;r=self.read(folder/'execution-result.json');raw=self.read(folder/'browser-results.json');before=self.read(folder/'all-inputs-before.json');after=self.read(folder/'all-inputs-after.json');self.snapshot_pair(before,after)
        need(r['headBefore']==r['headAfter']==self.head and true(r['accepted']) and exact_int(r['exitCode'],0) and all_true(r['checks']),'Browser did not accept current source')
        self.ref(folder/'browser.log',r['browserLogSha256']);a=self.read(folder/'inputs-before.json');b=self.read(folder/'inputs-after.json');need(a['files']==b['files'] and a['head']==b['head']==self.head and a['status']==b['status']==[],'Browser source/dist changed')
        for p,digest in b['files'].items():need(sha(pathlib.Path(p))==digest,'Browser/dist/harness current bytes changed: '+p)
        need(raw['scenarioFilter'] is None and len(raw['results'])==count,'Browser scenario subset/count')
        expected=self.contract['expectedBrowser16Names'] if count==16 else self.contract['expectedBrowser28Names'];need(collections.Counter(x['name'] for x in raw['results'])==collections.Counter(expected),'Browser original scenarios changed')
        need(all(x['status']=='passed' for x in raw['results']),'Browser scenario failure')
        if count==16:
            need(raw['counts']==r['counts']=={'tests':16,'pass':16,'fail':0},'Browser16 summary mismatch')
            for x in raw['results']:need(not x['errors'] and not x['blocked'] and not x['audit']['unknown'] and not x['audit']['network'],'Browser16 error/IPC/network audit')
            index=self.read(folder/'evidence-index.json');need(true(index['accepted']) and index['sourceHead']==self.head,'Browser16 evidence index not current')
            for x in index['artifacts']:self.referenced(x)
            binding=self.read(folder/'build-and-baseline-binding.json')
            for key in ['buildResult','buildAfter','buildLog']:self.referenced(binding[key])
            for x in binding['distArtifactsFromActualBuildLog']:need(sha(ROOT/x['path'])==x['sha256'],'Actual emitted dist changed')
        else:
            need(raw['commit']==self.head and raw['chromiumExecutable']=='/usr/bin/chromium' and true(raw['browserLaunched']),'Wrong Chromium/source')
            expected_counts={'passed':28,'failed':0,'runtimeErrors':0,'blockedRequests':0,'unknownIpc':0,'externalFetch':0};need(raw['counts']==r['counts']==expected_counts,'Browser28 summary/audits failed')
            self.referenced(r['baselineResults']);self.read(folder/'build-dist-reuse-binding.json')
        for p in folder.rglob('*'):
            if p.is_file() and p.suffix in {'.json','.log','.png','.html','.sha256','.py','.cjs'}:self.ref(p)
        return {'command':r['command'],'counts':r['counts'],'durationSeconds':r['durationSeconds'],'scope':'Actual Chromium + actual Vue production dist; synthetic IPC only; not Tauri/SQLite/provider/desktop acceptance'}
    def reviews(self):
        privacy=self.read(BASE/'chat-asset-stats/independent-contract-privacy-final-5b4a5b6-review.json');fix=self.read(BASE/'targeted-fixes/independent-review-e5fed60.json')
        need(true(privacy['staticReviewPassed']) and true(fix['staticReviewPassed']) and fix['sourceHead']==self.head and not fix['newConcreteBlockers'],'Static contract review failed')
        for x in privacy['sourceManifest']:need(sha(ROOT/x['path'])==x['sha256'],'Reviewed privacy source changed')
        for x in fix['changedFileEvidence']:need(sha(ROOT/x['path'])==x['currentSha256'],'Reviewed fixture correction changed')
        return {'privacyReviewedHead':privacy['sourceHead'],'testOnlyFollowupHead':fix['sourceHead'],'allReviewedSourceBytesStillMatch':True,'notBehaviorAcceptance':True}
    def history(self):
        failures=[]
        for p in sorted(BASE.rglob('*.json')):
            if HERE in p.parents:continue
            try:d=json.loads(p.read_text())
            except (ValueError,OSError):continue
            if not isinstance(d,dict):continue
            key=next((k for k in ['exitCode','commandExitCode','actualCommandExitCode'] if type(d.get(k)) is int and d[k]!=0),None)
            if key:failures.append({'receipt':self.ref(p),'actualRecordedNonzeroField':key,'exitCode':d[key],'sourceHead':d.get('sourceHead',d.get('headBefore')),'accepted':False,'note':'Historical actual failure, never replaced by later green results'})
        return failures

def main():
    p=argparse.ArgumentParser(description=__doc__);mode=p.add_mutually_exclusive_group(required=True);mode.add_argument('--draft',action='store_true');mode.add_argument('--finalize',action='store_true');p.add_argument('--output',required=True,type=pathlib.Path);p.add_argument('--legacy-browser-dir',default='browser/legacy28-frozen-02');p.add_argument('--full-session-receipt',type=pathlib.Path);a=p.parse_args()
    need(a.output.is_absolute() and a.output.parent.resolve()==HERE.resolve(),'Output must be a fresh explicit file in final-audit only')
    need(not a.output.exists(),'Never replace a prior draft/final/refusal')
    contract_path=HERE/'prepared-contract.json';need(sha(contract_path)==CONTRACT_SHA,'Prepared contract changed');audit=Audit(json.loads(contract_path.read_text()));audit.ref(contract_path,CONTRACT_SHA)
    gates=[]
    actions=[('currentSource',audit.source),('nativeCheck',lambda:audit.native_build('statistics-all-targets-02','check')),('nativeBuild',lambda:audit.native_build('statistics-native-build-02','build')),('nativeTargeted',lambda:audit.native('statistics-native-targeted-02','targeted')),('nativeFull',lambda:audit.native('statistics-native-full-01','full')),('nativeFullObservedOuter',lambda:audit.observed_full_outer(a.full_session_receipt)),('frontendBuildBytes',audit.frontend_build),('node98',audit.node),('browser16',lambda:audit.browser('browser/stats-frozen-01',16)),('browser28',lambda:audit.browser(a.legacy_browser_dir,28)),('independentContractReviews',audit.reviews)]
    for name,run in actions:
        refs_before=set(audit.refs)
        try:value=run();gate={'gate':name,'state':'passed','accepted':True,'actual':value}
        except Pending as e:gate={'gate':name,'state':'pending','accepted':None,'reason':str(e)}
        except Exception as e:gate={'gate':name,'state':'failed','accepted':False,'errorType':type(e).__name__,'reason':str(e)}
        gate['evidence']=[v for k,v in audit.refs.items() if k not in refs_before];gates.append(gate)
    failed=[g['gate'] for g in gates if g['state']=='failed'];pending=[g['gate'] for g in gates if g['state']=='pending'];ready=not failed and not pending
    report={'schemaVersion':1,'mode':'final' if a.finalize else 'draft','recordedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':audit.head,'codeHead':audit.head,'acceptedCurrentCloudCodeRegression':True if a.finalize and ready else (False if failed else None),'allRequiredGatesObservedPassed':ready,'pendingGates':pending,'failedGates':failed,'gates':gates,'retainedFailureHistory':audit.history(),'evidenceRoot':str(BASE),'allBoundEvidence':list(audit.refs.values()),'auditor':{'relativePath':os.path.relpath(__file__,BASE),'sha256':sha(pathlib.Path(__file__))},'scope':audit.contract['scope'],'limits':['Browser is synthetic IPC, not native Tauri/SQLite/provider or DMG acceptance.','No structured AI analysis, approvals or autonomous orchestration acceptance is implied.','Earlier-stage or failed-source results remain historical; current-source full completion and externally observed outer exit are mandatory.','Frontend npm build is source-byte-equivalent reuse from its recorded earlier HEAD, explicitly not an e5 build execution.']}
    if a.finalize and not ready:
        refusal=a.output.with_name(a.output.stem+'.refusal.json');write_new(refusal,report);print(json.dumps({'finalizeRefused':True,'pending':pending,'failed':failed,'refusal':str(refusal)}));return 2
    write_new(a.output,report);print(json.dumps({'output':str(a.output),'sha256':sha(a.output),'mode':report['mode'],'pending':pending,'failed':failed,'accepted':report['acceptedCurrentCloudCodeRegression']}));return 0
if __name__=='__main__':sys.exit(main())
