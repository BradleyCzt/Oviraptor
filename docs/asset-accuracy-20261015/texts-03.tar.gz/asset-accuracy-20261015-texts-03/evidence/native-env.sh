# Private Debian GTK/WebKit sysroot and pinned existing Rust toolchain only.
source /workspace/toolchain/native-env.sh
# Never write the previous accepted-target or historical baseline target.
export CARGO_TARGET_DIR=/workspace/asset-accuracy-target
export CARGO_BUILD_JOBS=2
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0
export CARGO_PROFILE_TEST_OPT_LEVEL=1
export CARGO_PROFILE_TEST_DEBUG_ASSERTIONS=true
export CARGO_PROFILE_TEST_OVERFLOW_CHECKS=true
