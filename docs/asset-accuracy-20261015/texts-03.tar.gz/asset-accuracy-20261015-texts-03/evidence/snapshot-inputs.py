#!/usr/bin/env python3
"""Inventory actual native/audit inputs using the already reviewed retirement policy.

No Git ignore filtering is applied within those source roots. Every regular file,
including ignored files and arbitrary extensions, is hashed; symlinks and special
files fail closed. This module never reads file contents into evidence output.
"""
import datetime, hashlib, json, pathlib, re, stat, subprocess
ROOT = pathlib.Path('/workspace/Oviraptor-asset-accuracy-20261015')
POLICY_PATH = pathlib.Path(__file__).parent / 'audit-policy.json'
POLICY = json.loads(POLICY_PATH.read_text())['audit_policy']
VERSION = 'asset-accuracy-native-audit-tracked-untracked-v1'
CATEGORIES = ('nativeInputs', 'auditInputs', 'trackedInputs', 'untrackedInputs')

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def inventory(paths, *, missing_tracked=False):
    found = {}
    def visit(path):
        if missing_tracked and not path.exists() and not path.is_symlink():
            found[path.relative_to(ROOT).as_posix()] = None
            return
        metadata = path.lstat()
        if stat.S_ISLNK(metadata.st_mode):
            raise RuntimeError('Symlink input is not accepted: ' + str(path))
        if stat.S_ISDIR(metadata.st_mode):
            for child in sorted(path.iterdir()):
                visit(child)
        elif stat.S_ISREG(metadata.st_mode):
            found[path.relative_to(ROOT).as_posix()] = sha(path)
        else:
            raise RuntimeError('Unsupported input: ' + str(path))
    for path in paths:
        visit(path)
    return dict(sorted(found.items()))

def snapshot():
    helper = ROOT / 'src-tauri/src/commands/agent_tests_backend_literal.rs'
    source = helper.read_text()
    for constant, expected in (
        ('RETIREMENT_SOURCE_SCOPES', POLICY['source_roots']),
        ('RETIREMENT_OPTIONAL_SOURCE_SCOPES', POLICY['optional_only_if_absent']),
    ):
        match = re.search(r'const ' + constant + r':.*?= &\[(.*?)\];', source, re.S)
        actual = re.findall(r'"([^\"]+)"', match[1]) if match else None
        matches = (actual == expected if constant == 'RETIREMENT_SOURCE_SCOPES' else actual is not None and len(actual) == len(expected) and set(actual) == set(expected))
        if not matches:
            raise RuntimeError('Retirement input scope policy drift requires review: ' + constant)
    audit_roots, missing = [], []
    for name in POLICY['source_roots']:
        path = ROOT / name
        if not path.exists() and not path.is_symlink() and name in POLICY['optional_only_if_absent']:
            missing.append(name)
        else:
            audit_roots.append(path)
    for name in POLICY['extra_roots']:
        path = ROOT / name
        if path.exists() or path.is_symlink():
            audit_roots.append(path)
    extensions = set(POLICY['root_build_inputs']['extensions'])
    names = set(POLICY['root_build_inputs']['names'])
    for name in POLICY['root_build_inputs']['directories']:
        for path in sorted((ROOT / name).iterdir()):
            if not path.is_dir() and (path.suffix.lstrip('.') in extensions or path.name in names):
                audit_roots.append(path)
    native_roots = [ROOT / 'src-tauri', ROOT / 'tools/run_with_subreaper.py']
    if (ROOT / '.cargo').exists() or (ROOT / '.cargo').is_symlink():
        native_roots.append(ROOT / '.cargo')
    tracked = [name for name in git('ls-files', '-z').decode().split('\0') if name]
    untracked = [name for name in git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0') if name]
    result = {
        'snapshotVersion': VERSION,
        'nativeInputs': inventory(native_roots),
        'auditInputs': inventory(audit_roots),
        'trackedInputs': inventory([ROOT / name for name in tracked], missing_tracked=True),
        'untrackedInputs': inventory([ROOT / name for name in untracked]),
        'auditPolicy': dict(POLICY, missing_optional_roots=missing),
        'auditPolicyReference': str(POLICY_PATH),
        'auditPolicyReferenceSha256': sha(POLICY_PATH),
        'auditPolicySource': helper.relative_to(ROOT).as_posix(),
        'auditPolicySourceSha256': sha(helper),
    }
    combined = {}
    for category in CATEGORIES:
        for name, digest in result[category].items():
            if name in combined and combined[name] != digest:
                raise RuntimeError('Input changed while capturing overlapping roots: ' + name)
            combined[name] = digest
    result.update({
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'head': git('rev-parse', 'HEAD').decode().strip(),
        'status': git('status', '--porcelain=v1', '--untracked-files=all').decode().splitlines(),
        'files': dict(sorted(combined.items())),
    })
    return result

def compare(before, after):
    checks = {}
    for category in (*CATEGORIES, 'files'):
        left, right = before[category], after[category]
        checks[category] = {
            'before': len(left), 'after': len(right),
            'added': sorted(right.keys() - left.keys()),
            'removed': sorted(left.keys() - right.keys()),
            'changed': sorted(name for name in left.keys() & right.keys() if left[name] != right[name]),
        }
    return checks

def same_inputs(before, after):
    return (before.get('snapshotVersion') == after.get('snapshotVersion') == VERSION
        and all(before.get(category) == after.get(category) for category in CATEGORIES)
        and before.get('files') == after.get('files')
        and before.get('auditPolicy') == after.get('auditPolicy')
        and before.get('auditPolicyReferenceSha256') == after.get('auditPolicyReferenceSha256')
        and before.get('auditPolicySourceSha256') == after.get('auditPolicySourceSha256'))
