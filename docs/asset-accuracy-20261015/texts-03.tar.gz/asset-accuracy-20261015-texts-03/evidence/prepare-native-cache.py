from pathlib import Path
import os,sys,stat,shutil,hashlib,json,datetime,time
OUT=Path('/workspace/validation/asset-accuracy-20261015');SOURCE=Path('/workspace/accepted-target/debug');DEST=Path('/workspace/asset-accuracy-target/debug')
REFERENCE=Path('/workspace/validation/local-integration-20261015/native-full-accepted-03-result.json')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as s:
  for b in iter(lambda:s.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
reference=json.loads(REFERENCE.read_text());binary=Path(reference['binary']);assert sha(binary)==reference['binarySha256'];assert reference['accepted'] is True
old_receipt_sha=sha(REFERENCE);old_log=REFERENCE.with_name('native-full-accepted-03.log');old_log_sha=sha(old_log);assert old_log_sha==reference['logSha256']
assert not DEST.parent.exists(),'Use a fresh target; never blend unknown build outputs'
started=utc();tick=time.monotonic();free_before=shutil.disk_usage(OUT).free
files=[]
for scope in ['deps','.fingerprint','build']:
 for base,dirs,names in os.walk(SOURCE/scope):
  dirs[:]=[d for d in dirs if 'oviraptor' not in d]
  for name in names:
   if 'oviraptor' in name:continue
   src=Path(base)/name;st=src.lstat();assert stat.S_ISREG(st.st_mode),f'Unreviewed non-regular generated artifact: {src}'
   files.append((src,src.relative_to(SOURCE),st.st_size))
required=sum(s for _,_,s in files);assert free_before>required+2*1024**3,'Reserve at least2GiB after dependency seed'
print(json.dumps({'stage':'copying','files':len(files),'bytes':required,'source':str(SOURCE),'target':str(DEST),'incrementalCopied':False,'hardlinksUsed':False}),flush=True)
manifest=[]
for i,(src,relative,size) in enumerate(files):
 dest=DEST/relative;dest.parent.mkdir(parents=True,exist_ok=True)
 before=sha(src);shutil.copy2(src,dest);after=sha(dest);assert before==after
 ss=src.stat();ds=dest.stat();assert (ss.st_dev,ss.st_ino)!=(ds.st_dev,ds.st_ino)
 manifest.append({'path':relative.as_posix(),'bytes':size,'sha256':before})
 if (i+1)%2500==0:print(json.dumps({'stage':'copied','files':i+1}),flush=True)
assert not (DEST/'incremental').exists()
assert not list((DEST/'deps').glob('*oviraptor*'))
assert not list((DEST/'.fingerprint').glob('*oviraptor*'))
assert not list((DEST/'build').glob('*oviraptor*'))
assert sha(binary)==reference['binarySha256'] and sha(REFERENCE)==old_receipt_sha and sha(old_log)==old_log_sha
report={'startedAtUtc':started,'finishedAtUtc':utc(),'durationSeconds':round(time.monotonic()-tick,3),'source':str(SOURCE),'target':str(DEST),'filesCopied':len(manifest),'bytesCopied':required,'sourceApplicationFilesExcluded':True,'sourceIncrementalEntirelyExcluded':True,'ordinaryIndependentCopies':True,'sourceFilesNotWritten':True,'oldAcceptedBinary':{'path':str(binary),'sha256BeforeAndAfter':reference['binarySha256'],'bytes':binary.stat().st_size},'oldFull03Result':{'path':str(REFERENCE),'sha256BeforeAndAfter':old_receipt_sha},'oldFull03Log':{'path':str(old_log),'sha256BeforeAndAfter':old_log_sha},'freeBytesBefore':free_before,'freeBytesAfter':shutil.disk_usage(OUT).free,'compilationStarted':False,'copiedFiles':manifest}
with (OUT/'cache-seed-result.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in report.items() if k!='copiedFiles'}),flush=True)
