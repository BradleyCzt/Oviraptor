#!/usr/bin/env python3
import datetime,hashlib,json,pathlib,subprocess,sys
ROOT=pathlib.Path('/workspace/Oviraptor-asset-accuracy-20261015')
BASE=pathlib.Path('/workspace/validation/asset-accuracy-20261015')
EXPECTED='34e802a6f8d4fc093efa1d3ee732daf767d0df44'
OUT=BASE/'stats-certified-node-01'
OUT.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
status=subprocess.check_output(['git','status','--porcelain=v1'],cwd=ROOT,text=True)
assert head==EXPECTED and not status,(head,status)
paths=sorted(ROOT.glob('tools/test_*.cjs'))
assert len(paths)==98,len(paths)
files=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in paths]
command=['env','OVIRAPTOR_TEST_NO_SANDBOX=1','CHROME_BINARY=/usr/bin/chromium','node','--test','--test-reporter=tap','--test-concurrency=1',*[r['path'] for r in files]]
selection={'scope':'entire actual tools/test_*.cjs, no name filters or added skips','expectedHead':EXPECTED,'head':head,'clean':not status,'fileCount':len(files),'command':command,'explicitEnvironment':{'OVIRAPTOR_TEST_NO_SANDBOX':'1','CHROME_BINARY':'/usr/bin/chromium'},'reason':'Existing local synthetic fixture CI opt-in; container SUID sandbox unavailable; production and system permissions unchanged.','fixtureReview':{'path':'tools/test_native_runtime.cjs','sha256':sha(ROOT/'tools/test_native_runtime.cjs'),'startLine':44,'endLine':53},'files':files,'selectedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with (OUT/'selection.json').open('x') as f:json.dump(selection,f,indent=2);f.write('\n')
with (OUT/'wrapper.log').open('x') as stream:
 result=subprocess.run([sys.executable,str(BASE/'run-command.py'),'stats-certified-node-01',*command],stdout=stream,stderr=subprocess.STDOUT)
print(json.dumps({'exitCode':result.returncode,'selection':str(OUT/'selection.json'),'log':str(BASE/'stats-certified-node-01.log')}))
sys.exit(result.returncode)
