#!/usr/bin/env python3
"""Independent final preservation/input verification, callable only after suite return."""
import datetime,hashlib,importlib.util,json,pathlib,re,sys
OUT=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path('/workspace/Oviraptor-asset-accuracy-20261015')
def read(p):return json.loads(p.read_text())
def sha(p):
 with p.open('rb') as s:return hashlib.file_digest(s,'sha256').hexdigest()
def save(p,value):
 with p.open('x') as s:json.dump(value,s,indent=2);s.write('\n')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def stamp(value):return datetime.datetime.fromisoformat(value)
def main():
 prefix=sys.argv[1]
 if not re.fullmatch('[A-Za-z0-9][A-Za-z0-9._-]*',prefix):raise SystemExit('Plain label required')
 resultpath=OUT/(prefix+'-result.json');superpath=OUT/('supervisor-'+prefix+'-receipt.json')
 r=read(resultpath);supervisor=read(superpath);after=read(OUT/(prefix+'-after.json'));before=read(OUT/(prefix+'-before.json'))
 spec=importlib.util.spec_from_file_location('post_native_helpers',OUT/'run-command.py');helpers=importlib.util.module_from_spec(spec);spec.loader.exec_module(helpers)
 current=helpers.snap();snapshotpath=OUT/(prefix+'-independent-post-snapshot.json');save(snapshotpath,current)
 protected=[]
 for old in read(OUT/'environment-plan.json')['protectedOldAcceptance']['artifacts']:
  path=pathlib.Path(old['path']);actual=sha(path);protected.append({'path':str(path),'expectedSha256':old['sha256'],'actualSha256':actual,'expectedBytes':old['bytes'],'actualBytes':path.stat().st_size,'unchanged':actual==old['sha256'] and path.stat().st_size==old['bytes']})
 retained=[]
 for directory in ['retained-45d5434','retained-5b4a5b6-failed-targeted']:
  proofpath=OUT/directory/'retention-proof.json';proof=read(proofpath);path=pathlib.Path(proof['verifiedRetainedPath']);actual=sha(path);retained.append({'proof':str(proofpath),'proofSha256':sha(proofpath),'binary':str(path),'expectedSha256':proof['sha256'],'actualSha256':actual,'actualBytes':path.stat().st_size,'unchanged':not path.is_symlink() and actual==proof['sha256'] and path.stat().st_size==proof['sizeBytes']})
 cases={row['name']:row['status'] for row in r['caseResults']};selection=read(OUT/(prefix+'-selection.json'));added=selection['caseMigration']['added'];fixed=read(OUT/'statistics-native-targeted-01-result.json')['failedCaseNames'];declarations=read(OUT/'statistics-frozen-required-case-declarations.json');stats=[n for row in declarations['rows'][:2] for n in row['requiredNames']]
 checks={
  'fullCollectorAccepted':r['accepted'] is True and all(r['checks'].values()),
  'independentSupervisorActualExitZero':supervisor['actualProcessExitCode']==0 and supervisor['processCompletionRecorded'] is True,
  'supervisorBindsResultAndLog':supervisor['fullResultSha256']==sha(resultpath) and supervisor['logSha256']==sha(OUT/(prefix+'.log')),
  'frozenHeadStillClean':current['head']==r['sourceHead']==supervisor['sourceHead']==supervisor['actualHeadBefore']==supervisor['actualHeadAfter'] and not current['status'],
  'nativeAuditTrackedUntrackedPathSetsAndHashesStillEqual':helpers.inputs.same_inputs(before,after) and helpers.inputs.same_inputs(after,current),
  'currentBinaryStillMatches':sha(pathlib.Path(r['binary']))==r['binarySha256'],
  'allOldFull03ArtifactsPreserved':all(x['unchanged'] for x in protected),
  'bothHistoricalIndependentBinariesPreserved':all(x['unchanged'] for x in retained),
  'runnerHelpersStillMatchFull':all(sha(OUT/n)==digest for n,digest in r['helperSha256'].items()),
  'supervisorStillMatchesRecordedSha':sha(OUT/'supervise-native-suite.py')==supervisor['supervisorSha256'] and supervisor['supervisorUnchanged'] is True,
  'postSnapshotAfterActualFullAndSupervisorFinish':stamp(current['utc'])>stamp(r['finishedAtUtc']) and stamp(current['utc'])>stamp(supervisor['finishedAtUtc']),
  'all103NewCasesPassed':len(added)==103 and all(cases.get(n)=='ok' for n in added),
  'all20StatisticsCasesPassed':len(stats)==20 and all(cases.get(n)=='ok' for n in stats),
  'allSixPreviousFailuresPassed':len(fixed)==6 and all(cases.get(n)=='ok' for n in fixed),
 }
 value={'recordedAtUtc':now(),'sourceHead':r['sourceHead'],'fullResult':str(resultpath),'fullResultSha256':sha(resultpath),'independentSupervisorReceipt':str(superpath),'independentSupervisorReceiptSha256':sha(superpath),'fullFinishedAtUtc':r['finishedAtUtc'],'supervisorFinishedAtUtc':supervisor['finishedAtUtc'],'postSnapshot':str(snapshotpath),'postSnapshotSha256':sha(snapshotpath),'postSnapshotUtc':current['utc'],'inputComparisons':helpers.inputs.compare(after,current),'protectedOldFull03Artifacts':protected,'historicalIndependentBinaryCopies':retained,'checks':checks,'accepted':all(checks.values()),'verificationScriptSha256':sha(pathlib.Path(__file__).resolve())}
 reportpath=OUT/(prefix+'-independent-post-verification.json');save(reportpath,value);print(json.dumps({'postVerification':str(reportpath),'accepted':value['accepted'],'checks':checks}));return 0 if value['accepted'] else 1
if __name__=='__main__':sys.exit(main())
