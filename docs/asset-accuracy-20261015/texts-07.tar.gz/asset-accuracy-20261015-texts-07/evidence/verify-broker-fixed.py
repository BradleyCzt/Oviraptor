#!/usr/bin/env python3
"""Bounded post-fix actual exact repetition; all raw results preserved."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import datetime,hashlib,json,os,re,subprocess,sys,threading,time
OUT=Path(__file__).resolve().parent;ROOT=Path('/workspace/Oviraptor-asset-accuracy-20261015')
BUILD='statistics-native-build-03';HEAD='34e802a6f8d4fc093efa1d3ee732daf767d0df44'
CASE='scanning::agent_tests::broker_checks_role_capability_revocation_expiry_and_fencing'
DEST=OUT/'statistics-broker-fixed-repeat-iterations-03';LOCK=threading.Lock()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,r):
 with p.open('x') as f:json.dump(r,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def one(i,phase,command):
 log=DEST/f'iteration-{i:03}.log';start=utc();tick=time.monotonic()
 with log.open('x') as f:completed=subprocess.run(command,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
 body=log.read_text();summary=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([\d.]+)s$',body,re.M)
 cases=re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)',body,re.M)
 valid=completed.returncode==0 and summary and summary[-1][0:6]==('ok','1','0','0','0','3827') and cases==[(CASE,'ok')]
 row={'iteration':i,'phase':phase,'startedAtUtc':start,'finishedAtUtc':utc(),'durationSeconds':round(time.monotonic()-tick,4),'actualExitCode':completed.returncode,'exactOneCaseActuallyPassed':bool(valid),'summary':summary,'caseLines':cases,'log':str(log),'logSha256':sha(log)}
 save(DEST/f'iteration-{i:03}-result.json',row)
 with LOCK:
  print(json.dumps(row),flush=True)
  if not valid:print(body,flush=True)
 return row
def main():
 e=json.loads((OUT/(BUILD+'-entry-result.json')).read_text());assert e['accepted'] is True and all(e['checks'].values()) and e['sourceHead']==HEAD
 b=Path(e['artifact']['executable']);expected=e['artifact']['sha256'];assert not b.is_symlink() and sha(b)==expected;assert not DEST.exists();DEST.mkdir()
 argv=['python3','tools/run_with_subreaper.py',str(b),'--exact',CASE,'--test-threads=1'];rows=[];started=utc();first_failure=None
 for i in range(1,21):
  row=one(i,'sequential',argv);rows.append(row)
  if not row['exactOneCaseActuallyPassed']:first_failure=i;break
 if first_failure is None:
  for batch in range(8):
   with ThreadPoolExecutor(max_workers=8) as pool:
    pending=[pool.submit(one,21+batch*8+j,'eight-process',argv) for j in range(8)]
    for f in as_completed(pending):
     row=f.result();rows.append(row)
     if not row['exactOneCaseActuallyPassed'] and first_failure is None:first_failure=row['iteration']
   if first_failure is not None:break
 checks={'all84IterationsActuallyExecuted':len(rows)==84,'everyExactOneCasePassed':all(r['exactOneCaseActuallyPassed'] for r in rows),'sourceHeadStillFrozen':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD,'binaryStillMatches':sha(b)==expected}
 result={'startedAtUtc':started,'finishedAtUtc':utc(),'sourceHead':HEAD,'buildPrefix':BUILD,'binary':str(b),'binarySha256Before':expected,'binarySha256After':sha(b),'command':argv,'sequentialPlan':20,'parallelPlan':{'processes':8,'batches':8,'total':64},'actualIterationCount':len(rows),'firstFailure':first_failure,'checks':checks,'accepted':all(checks.values()),'iterations':sorted(rows,key=lambda r:r['iteration'])}
 save(DEST/'repeat-result.json',result);return next((r['actualExitCode'] or 1 for r in rows if not r['exactOneCaseActuallyPassed']),0 if result['accepted'] else 1)
if __name__=='__main__':sys.exit(main())
