#!/usr/bin/env python3
"""Independent process-exit observer for an existing, unchanged native suite runner."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/Oviraptor-asset-accuracy-20261015')
RUNNER = OUT / 'run-native-suite.py'

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def digest(path):
    if not path.is_file():
        return None
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def save_exclusive(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())

def actual_head():
    return subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('build_prefix')
    parser.add_argument('prefix')
    parser.add_argument('--head', required=True)
    parser.add_argument('--mode', required=True, choices=['targeted', 'full'])
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    if not args.execute:
        parser.error('Explicit --execute is required; preparation does not execute tests')
    if not re.fullmatch('[0-9a-f]{40}', args.head):
        parser.error('Full source HEAD required')
    for name in [args.prefix, args.build_prefix]:
        if not re.fullmatch('[A-Za-z0-9][A-Za-z0-9._-]*', name) or name in {'.', '..'}:
            parser.error('Plain evidence labels required')
    start_path = OUT / ('supervisor-' + args.prefix + '-started.json')
    receipt_path = OUT / ('supervisor-' + args.prefix + '-receipt.json')
    if start_path.exists() or receipt_path.exists():
        parser.error('Fresh supervisor prefix required; evidence cannot be overwritten')
    command = [sys.executable, str(RUNNER), args.build_prefix, args.prefix, '--head', args.head, '--mode', args.mode, '--execute']
    started = utc()
    before_head = actual_head()
    own_sha = digest(Path(__file__).resolve())
    runner_sha = digest(RUNNER)
    save_exclusive(start_path, {
        'sourceHead': args.head, 'actualHeadBefore': before_head,
        'startedAtUtc': started, 'argv': command, 'mode': args.mode,
        'supervisorSha256': own_sha, 'runnerSha256Before': runner_sha,
        'processCompletionRecorded': False,
    })
    completed = subprocess.run(command, cwd=ROOT)
    finished = utc()
    result_path = OUT / (args.prefix + '-result.json')
    log_path = OUT / (args.prefix + '.log')
    receipt = {
        'sourceHead': args.head, 'actualHeadBefore': before_head,
        'actualHeadAfter': actual_head(), 'startedAtUtc': started,
        'finishedAtUtc': finished, 'argv': command, 'mode': args.mode,
        'actualProcessExitCode': completed.returncode,
        'processCompletionRecorded': True,
        'fullResultPath': str(result_path), 'fullResultSha256': digest(result_path),
        'logPath': str(log_path), 'logSha256': digest(log_path),
        'supervisorSha256': own_sha, 'supervisorUnchanged': digest(Path(__file__).resolve()) == own_sha,
        'runnerSha256Before': runner_sha, 'runnerSha256After': digest(RUNNER),
        'stdoutAndStderr': 'inherited from supervisor; unchanged suite runner owns raw test log',
    }
    save_exclusive(receipt_path, receipt)
    print(json.dumps({'independentSupervisorReceipt': str(receipt_path), 'actualProcessExitCode': completed.returncode, 'finishedAtUtc': finished}), flush=True)
    if completed.returncode < 0:
        sig = -completed.returncode
        signal.signal(sig, signal.SIG_DFL)
        os.kill(os.getpid(), sig)
        return 128 + sig
    return completed.returncode

if __name__ == '__main__':
    sys.exit(main())
