#!/usr/bin/env python3
"""Parse actual TAP after completion; do not rerun or rewrite assertions."""
import collections,hashlib,json,pathlib,re
ROOT=pathlib.Path('/workspace/Oviraptor-asset-accuracy-20261015')
BASE=pathlib.Path('/workspace/validation/asset-accuracy-20261015')
OUT=pathlib.Path(__file__).parent
EXPECTED='34e802a6f8d4fc093efa1d3ee732daf767d0df44'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,data):
 with (OUT/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
rp=BASE/'stats-certified-node-01-result.json';result=json.loads(rp.read_text())
selection=json.loads((OUT/'selection.json').read_text())
log=BASE/'stats-certified-node-01.log';lines=log.read_text().splitlines()
summary={k:float(v) if k=='duration_ms' else int(v) for k,v in re.findall(r'^# (tests|suites|pass|fail|cancelled|skipped|todo|duration_ms) ([0-9.]+)$','\n'.join(lines),re.M)}
assert all(k in summary for k in ['tests','pass','fail','skipped','cancelled','todo']),summary
rows=[]
for i,line in enumerate(lines):
 m=re.fullmatch(r'( *)(ok|not ok) (\d+) - (.+)',line)
 if not m:continue
 name,directive=(re.split(r' # (?:SKIP|TODO)\b',m[4],maxsplit=1)+[''])[:2]
 row={'line':i+1,'indent':len(m[1]),'status':m[2],'number':int(m[3]),'name':name,'skipped':bool(re.search(r' # SKIP\b',m[4])),'todo':bool(re.search(r' # TODO\b',m[4]))}
 if m[2]=='not ok':row['diagnosticLines']=lines[i+1:min(i+45,len(lines))]
 rows.append(row)
top=[r for r in rows if r['indent']==0]
name_counts=collections.Counter(r['name'] for r in rows)
selection_after=[{'path':f['path'],'sha256':sha(ROOT/f['path'])} for f in selection['files']]
exact_files=sorted(str(p.relative_to(ROOT)) for p in ROOT.glob('tools/test_*.cjs'))
checks={'beforeHeadExact':result['headBefore']==EXPECTED,'afterHeadExact':result['headAfter']==EXPECTED,'beforeClean':result['statusBefore']==[],'afterClean':result['statusAfter']==[],'allInputsUnchanged':result['allInputPathSetsAndHashesUnchanged'] is True,'auditPolicyUnchanged':result['auditPolicyUnchanged'] is True,'helpersUnchanged':result['helpersUnchanged'] is True,'selectionStillExact':exact_files==[f['path'] for f in selection['files']],'selectionHashesUnchanged':all(sha(ROOT/f['path'])==f['sha256'] for f in selection['files']),'caseRowsMatchSummary':len(rows)==summary['tests'],'expectedCaseArithmetic':summary['pass']+summary['fail']+summary['cancelled']+summary['skipped']+summary['todo']==summary['tests']}
prior=json.loads((BASE/'node-final-01/case-ledger.json').read_text())
checks['existingSkipSetUnchanged']=[r['name'] for r in rows if r['skipped']]==[r['name'] for r in prior if r['skipped']]
checks['explicitFixtureEnvironmentRecorded']=result['command'][:3]==['env','OVIRAPTOR_TEST_NO_SANDBOX=1','CHROME_BINARY=/usr/bin/chromium']
record={'scope':'entire actual tools/test_*.cjs run with concurrency=1; existing explicit skips reported, no CLI filter or added skip','sourceHead':EXPECTED,'fileCount':selection['fileCount'],'command':selection['command'],'explicitEnvironment':selection['explicitEnvironment'],'priorEnvironmentFailure':'node-final-01/summary.json','summary':summary,'exitCode':result['exitCode'],'durationSeconds':result['durationSeconds'],'caseRows':len(rows),'topLevelRows':len(top),'duplicateCaseNames':[{'name':n,'count':c} for n,c in sorted(name_counts.items()) if c>1],'checks':checks,'accepted':result['exitCode']==0 and summary['fail']==0 and summary['cancelled']==0 and all(checks.values()),'artifacts':{'commandResult':{'path':str(rp),'sha256':sha(rp)},'tap':{'path':str(log),'sha256':sha(log)},'selection':{'path':str(OUT/'selection.json'),'sha256':sha(OUT/'selection.json')}}}
save('case-ledger.json',rows);save('selection-after.json',selection_after);save('summary.json',record)
print(json.dumps({k:record[k] for k in ['accepted','fileCount','summary','exitCode','durationSeconds','caseRows','topLevelRows','checks']}))
