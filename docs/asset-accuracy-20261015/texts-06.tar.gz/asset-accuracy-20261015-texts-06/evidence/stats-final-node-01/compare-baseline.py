#!/usr/bin/env python3
"""Bind the actual accepted old TAP and new focused TAP, compare occurrences."""
import collections,hashlib,json,pathlib,re
ROOT=pathlib.Path('/workspace/Oviraptor-asset-accuracy-20261015')
BASE=pathlib.Path('/workspace/validation/asset-accuracy-20261015')
OUT=pathlib.Path(__file__).parent
OLD=pathlib.Path('/workspace/validation/local-integration-20261015/node-final-05')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def saved(name,value):
 with (OUT/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def cases(p):
 result=[]
 for line,text in enumerate(p.read_text().splitlines(),1):
  m=re.fullmatch(r'( *)(ok|not ok) (\d+) - (.+)',text)
  if not m:continue
  title=m[4];d=re.search(r' # (SKIP|TODO)(?: (.*))?$',title)
  result.append({'name':title[:d.start()] if d else title,'status':m[2],'directive':d[1] if d else None,'reason':d[2] if d else None,'line':line,'indent':len(m[1])})
 return result
indexed=ROOT/'docs/local-incremental-20261015/final-verification.json'
doc=json.loads(indexed.read_text());reference=doc['gates']['nodeFull']['result']
old_result=OLD/'result.json';assert reference['path']==str(old_result) and reference['sha256']==sha(old_result)
old=json.loads(old_result.read_text());assert old['baseHead']==old['postHead']=='24179702c9d163e1d21bf9a23c4528589355166a'
assert old['outerExitCode']==0 and old['collectorExitCode']==0 and old['frozenInputsUnchanged'] is True
for name in ['all-node.tap','case-occurrences.json','test-files.json']:
 assert sha(OLD/name)==old['evidence'][name]['sha256'],name
baseline=cases(OLD/'all-node.tap');raw_baseline=json.loads((OLD/'case-occurrences.json').read_text())['caseOccurrences']
assert len(baseline)==old['summary']['tests']==1588
assert collections.Counter(r['name'] for r in baseline)==collections.Counter(r['title'] for r in raw_baseline)
focused_path=BASE/'frontend-tests/stats-focused-02.log';focus_result=BASE/'frontend-tests/stats-focused-02-result.json';focus_snapshot=BASE/'frontend-tests/stats-focused-02-after.json'
fj=json.loads(focus_result.read_text());assert fj['exitCode']==0 and fj['inputsUnchanged'] and fj['counts']['tests']==74 and fj['logSha256']==sha(focused_path)
fsha=json.loads(focus_snapshot.read_text())['files']['tools/test_asset_accuracy_ui.cjs'];assert fsha==sha(ROOT/'tools/test_asset_accuracy_ui.cjs')
focused=cases(focused_path);assert len(focused)==74 and all(r['status']=='ok' and not r['directive'] for r in focused)
current=cases(BASE/'stats-final-node-01.log');summary=json.loads((OUT/'summary.json').read_text());selection=json.loads((OUT/'selection.json').read_text())
assert len(current)==summary['summary']['tests']
b=collections.Counter(r['name'] for r in baseline);c=collections.Counter(r['name'] for r in current);f=collections.Counter(r['name'] for r in focused)
removed=b-c;added=c-b
sk=lambda rows:collections.Counter((r['name'],r['reason']) for r in rows if r['directive']=='SKIP')
bskip,cskip=sk(baseline),sk(current)
old_files=set(x for x in old['command'] if x.startswith('tools/') and x.endswith('.cjs'));new_files={x['path'] for x in selection['files']}
checks={'acceptedBaselineBoundByRepoIndex':True,'baselineTapAndOccurrenceShaVerified':True,'baselineRowsMatch1588':len(baseline)==1588,'currentRowsMatch1662':len(current)==1662,'noOriginalCaseOccurrenceRemoved':not removed,'actualAdditionEqualsFocused74OccurrenceMultiset':added==f,'entireCurrentMultisetEqualsBaselinePlusFocused':c==b+f,'skipOccurrenceAndReasonMultisetUnchanged':bskip==cskip,'baselineAndCurrentHaveExactly12SkippedOccurrences':sum(bskip.values())==sum(cskip.values())==12,'onlyNewTestFileIsAccuracySfc':new_files-old_files=={'tools/test_asset_accuracy_ui.cjs'} and not old_files-new_files,'newTestSourceShaBoundToFocusedAndFullRun':fsha==next(x['sha256'] for x in selection['files'] if x['path']=='tools/test_asset_accuracy_ui.cjs'),'currentFullRunAccepted':summary['accepted'] is True}
record={'scope':'actual TAP case occurrence and skip multiset preservation; duplicate names retain all occurrences','sourceHead':summary['sourceHead'],'baselineHead':old['baseHead'],'baselineTests':len(baseline),'currentTests':len(current),'focusedNewTests':len(focused),'removedOccurrences':dict(removed),'addedOccurrences':dict(added),'baselineSkipMultiset':[{'name':n,'reason':why,'count':num} for (n,why),num in sorted(bskip.items())],'currentSkipMultiset':[{'name':n,'reason':why,'count':num} for (n,why),num in sorted(cskip.items())],'checks':checks,'accepted':all(checks.values()),'bindings':[{'path':str(p),'sha256':sha(p)} for p in [indexed,old_result,OLD/'all-node.tap',OLD/'case-occurrences.json',focused_path,focus_result,focus_snapshot,OUT/'summary.json',BASE/'stats-final-node-01.log',OUT/'selection.json']]}
saved('baseline-preservation.json',record);print(json.dumps({'accepted':record['accepted'],'baseline':len(baseline),'current':len(current),'added':sum(added.values()),'removed':sum(removed.values()),'checks':checks}))
