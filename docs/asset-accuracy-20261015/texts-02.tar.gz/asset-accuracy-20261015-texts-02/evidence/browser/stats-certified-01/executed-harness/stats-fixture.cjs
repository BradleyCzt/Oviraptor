// Synthetic read contracts for real DOM validation. No SQLite, provider or target execution.
module.exports = function statsFixture(options={}) {
 const qa=window.__QA__,old=window.__TAURI_INTERNALS__.invoke,clone=x=>JSON.parse(JSON.stringify(x));
 if(options.statsLocale)localStorage.setItem('oviraptor-locale',options.statsLocale);
 if(options.statsActivity)for(const snapshot of Object.values(qa.snapshots))qa.addToolActivity(snapshot.conversation.id,snapshot.messages[0].id,'assets_get_stats','completed','Exact project inventory 77; returned sample 20. Unknown states remain separate.');
 if(!options.statsMode)return;
 qa.statsMode=options.statsMode;qa.statsReads=[];qa.statsPending=[];qa.statsMarks=[];qa.statsOpened=[];qa.statsMarked=false;
 qa.statsRelease=(index,kind='page',overrides={})=>{const slot=qa.statsPending[index];if(!slot)throw Error('synthetic_stats_no_pending');if(kind==='reject')slot.reject(Error('Synthetic current read failed'));else slot.resolve(qa.statsPage(slot.query,overrides));};
 const summary=(x={})=>({all:0,pending:0,uncertain:0,confirmed:0,rejected:0,notApplicable:0,sentToAgent:0,...x});
 const seed=clone(qa.accuracyAssets[0]);seed.id=911;seed.title='Synthetic previous count snapshot';seed.host='https://counts.example.test/';seed.link=seed.host;
 qa.statsPage=(q,x={})=>({items:[],total:0,memberTotal:0,page:q.page,pageSize:q.pageSize,summary:summary(),...x});
 const hold=q=>new Promise((resolve,reject)=>qa.statsPending.push({query:clone(q),resolve,reject}));
 window.__TAURI_INTERNALS__.invoke=async(cmd,args={})=>{
  if(!['list_assets','mark_asset_entry_opened','plugin:opener|open_url'].includes(cmd))return old(cmd,args);
  qa.calls.push({cmd,args:clone(args)});
  if(cmd==='plugin:opener|open_url'){if(args.url!==seed.host)throw Error('synthetic_stats_unexpected_opener');qa.statsOpened.push(args.url);return;}
  if(cmd==='mark_asset_entry_opened'){if(args.projectId!==1||args.assetId!==911)throw Error('synthetic_stats_mark_scope');qa.mutations.push({cmd,args:clone(args)});qa.statsMarks.push(clone(args));qa.statsMarked=true;return '2026-10-15T13:00:00Z';}
  const q=args.query;if(q.projectId!==1||!Number.isSafeInteger(q.page)||q.page<1||![50,100,200].includes(q.pageSize))throw Error('synthetic_stats_query_contract');
  qa.statsReads.push(clone(q));
  if(qa.statsMode==='initial-failure'){if(qa.statsReads.length===1)return hold(q);return qa.statsPage(q);}
  if(qa.statsMode==='stale-failure'){if(q.search==='new-filter')return qa.statsPage(q);if(q.search)return hold(q);return qa.statsPage(q,{items:[clone(seed)],total:7,memberTotal:12,summary:summary({all:90,pending:52,confirmed:30,rejected:5,notApplicable:3})});}
  if(qa.statsMode==='late-filter'){if(q.search)return hold(q);return qa.statsPage(q);}
  if(qa.statsMode==='denominators')return qa.statsPage(q,{items:[clone(seed),{...clone(seed),id:912,host:'https://second-counts.example.test/',title:'Synthetic second count snapshot',extra:{}}],total:q.collapseIdenticalResponses?2:52,memberTotal:52,summary:summary({all:90,pending:52,confirmed:30,rejected:4,notApplicable:2,unknown:2})});
  if(qa.statsMode==='legacy')return {items:[clone(seed)],total:2,page:q.page,pageSize:q.pageSize};
  if(qa.statsMode==='seen'){if(qa.statsMarked)return hold(q);return qa.statsPage(q,{items:[clone(seed)],total:1,memberTotal:1,summary:summary({all:1,pending:1})});}
  throw Error('synthetic_stats_unimplemented_mode');
 };
};
