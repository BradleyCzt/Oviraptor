#!/usr/bin/env python3
import datetime,hashlib,importlib.util,json,pathlib,re,shutil,subprocess,sys,time
ROOT=pathlib.Path('/workspace/Oviraptor-asset-accuracy-20261015')
BASE=pathlib.Path('/workspace/validation/asset-accuracy-20261015')
SCRIPTS=pathlib.Path(__file__).parent
EXPECTED='5b4a5b61e715160cb1b09fc583cdc5e2eec28811'
prefix=sys.argv[1]
assert re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]*',prefix)
OUT=SCRIPTS.parent/prefix
OUT.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('inputs',BASE/'snapshot-inputs.py');inputs=importlib.util.module_from_spec(spec);spec.loader.exec_module(inputs)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,v):
 with (OUT/name).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def snap():
 files=set(ROOT.glob('src/**/*'))|set(ROOT.glob('dist/**/*'))|set(ROOT.glob('tools/qa/chat-ui/*'))|set(SCRIPTS.glob('*'))
 for name in ['package.json','package-lock.json','yarn.lock','vite.config.ts','tsconfig.json','index.html','tools/asset_accuracy_ui_harness.cjs','tools/test_asset_accuracy_ui.cjs']:files.add(ROOT/name)
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain=v1'],cwd=ROOT,text=True).splitlines(),'files':{str(p):sha(p) for p in sorted(files) if p.is_file()}}
(OUT/'executed-harness').mkdir()
for p in SCRIPTS.glob('*'):
 if p.is_file():shutil.copy2(p,OUT/'executed-harness'/p.name)
before=snap();save('inputs-before.json',before)
assert before['head']==EXPECTED and before['status']==[],before
fullbefore=inputs.snapshot();save('all-inputs-before.json',fullbefore)
buildroot=BASE/'frontend-tests'
build=json.loads((buildroot/'stats-build-02-after.json').read_text());br=json.loads((buildroot/'stats-build-02-result.json').read_text())
assert br['exitCode']==0 and br['inputsUnchanged'] is True
mismatch=[name for name,h in build['files'].items() if sha(ROOT/name)!=h]
assert not mismatch,mismatch
logged_artifacts=sorted(set(re.findall(r'^(dist/\S+)',(buildroot/'stats-build-02.log').read_text(),re.M)))
assert logged_artifacts and all((ROOT/p).is_file() for p in logged_artifacts)
old=(SCRIPTS.parent/'scripts/browser-accuracy.cjs').read_text()
current=(SCRIPTS/'browser-accuracy.cjs').read_text()
oldscenes=[line for line in old.splitlines() if line.startswith(' await scenario(')]
assert len(oldscenes)==8 and all(line in current.splitlines() for line in oldscenes)
save('build-and-baseline-binding.json',{'expectedHead':EXPECTED,'sourceMatchesAll409BoundBuildInputs':not mismatch,'buildResult':{'path':str(buildroot/'stats-build-02-result.json'),'sha256':sha(buildroot/'stats-build-02-result.json')},'buildAfter':{'path':str(buildroot/'stats-build-02-after.json'),'sha256':sha(buildroot/'stats-build-02-after.json')},'buildLog':{'path':str(buildroot/'stats-build-02.log'),'sha256':sha(buildroot/'stats-build-02.log')},'distArtifactsFromActualBuildLog':[{'path':p,'sha256':sha(ROOT/p),'bytes':(ROOT/p).stat().st_size} for p in logged_artifacts],'distManifestRecordedBeforeAndAfter':True,'original8ScenarioBodiesUnchanged':True,'originalHarnessSha256':sha(SCRIPTS.parent/'scripts/browser-accuracy.cjs'),'baselineSourceOnlyPrebuildShaNote':'The prior build runner bound frontend inputs but not output bytes. The actually loaded existing dist bytes are closed here before/after; emitted artifact names are cross-checked against that actual build log.'})
cmd=['node',str(SCRIPTS/'browser-accuracy.cjs'),str(OUT)]
started=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic()
with (OUT/'browser.log').open('x') as f:r=subprocess.run(cmd,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
duration=round(time.monotonic()-tick,3);after=snap();save('inputs-after.json',after)
fullafter=inputs.snapshot();save('all-inputs-after.json',fullafter)
changes=sorted(n for n in before['files'].keys()|after['files'].keys() if before['files'].get(n)!=after['files'].get(n))
result=json.loads((OUT/'browser-results.json').read_text()) if (OUT/'browser-results.json').exists() else None
checks={'beforeHeadExact':before['head']==EXPECTED,'afterHeadExact':after['head']==EXPECTED,'beforeClean':before['status']==[],'afterClean':after['status']==[],'browserInputsUnchanged':not changes,'allRepositoryInputsUnchanged':inputs.same_inputs(fullbefore,fullafter),'boundFrontendBuildInputsMatch':not mismatch,'original8ScenarioBodiesUnchanged':True,'noScenarioFilter':result is not None and result['scenarioFilter'] is None,'exact16Scenarios':result is not None and result['counts']['tests']==16,'noRuntimeErrorsUnknownIpcOrExternalRequests':result is not None and all(not row.get('errors') and not row.get('blocked') and not row.get('audit',{}).get('unknown') and not row.get('audit',{}).get('network') for row in result['results'])}
record={'scope':'Real system Chromium loading final existing production dist with strict synthetic local IPC. No native/DB/provider acceptance.','command':cmd,'startedAtUtc':started,'durationSeconds':duration,'exitCode':r.returncode,'headBefore':before['head'],'headAfter':after['head'],'inputCount':len(before['files']),'changedInputs':changes,'inputComparisons':inputs.compare(fullbefore,fullafter),'checks':checks,'counts':result['counts'] if result else None,'accepted':r.returncode==0 and result is not None and result['counts']['fail']==0 and all(checks.values()),'browserLogSha256':sha(OUT/'browser.log'),'runnerSha256':sha(pathlib.Path(__file__))}
save('execution-result.json',record)
print(json.dumps(record));sys.exit(r.returncode or int(not record['accepted']))
