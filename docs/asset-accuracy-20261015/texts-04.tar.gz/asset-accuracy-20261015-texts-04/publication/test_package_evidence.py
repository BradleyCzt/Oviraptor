"""Packer-only safety tests on new synthetic directories, never application QA."""
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tarfile
import tempfile
import unittest
from unittest import mock

HERE = Path(__file__).absolute().parent
spec = importlib.util.spec_from_file_location("evidence_packer", HERE / "package_evidence.py")
packer = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = packer
spec.loader.exec_module(packer)


class PackerTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="synthetic-packer-test-", dir=HERE)
        self.root = Path(self.temporary.name)
        self.source = self.root / "source"
        self.source.mkdir()
        self.policy = self.root / "policy.json"
        self.policy.write_bytes((HERE / "selection-policy.json").read_bytes())

    def tearDown(self):
        self.temporary.cleanup()

    def put(self, path, value):
        target = self.source / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(value.encode() if isinstance(value, str) else value)
        return target

    def publish(self, name="published", review=None):
        return packer.pack(self.source, self.root / name, "f" * 40, self.policy, review)

    def test_selection_preserves_failure_history_and_excludes_only_reviewed_payloads(self):
        self.put("old-failed.log", "test result: FAILED; original assertion retained\n")
        self.put("new-result.json", '{"exitCode":0,"meaning":"synthetic packer fixture only"}')
        self.put("retained-old/oviraptor_lib-test", b"old executable fixture")
        self.put("retained-old/retention-proof.json", "{}")
        patch = self.put("paused-wip/source-wip.patch", "potential URL fixture excluded unchanged")
        self.put("paused-wip/manifest.json", "{}")
        self.put("paused-wip/untracked-sources.tar.gz", b"redundant")
        self.put("__pycache__/helper.pyc", b"bytecode")
        selected, excluded = packer.scan_tree(self.source)
        self.assertEqual({row.path for row in selected}, {
            "old-failed.log", "new-result.json", "retained-old/retention-proof.json", "paused-wip/manifest.json"})
        excluded_patch = next(row for row in excluded if row["path"] == "paused-wip/source-wip.patch")
        self.assertEqual(excluded_patch["reason"], "potential_url_userinfo")
        self.assertEqual(excluded_patch["sha256"], packer.digest(patch.read_bytes()))

    def test_symlink_file_and_directory_are_not_followed_and_root_symlink_is_refused(self):
        self.put("real.log", "only selected record")
        secret = self.root / "outside"
        secret.mkdir()
        (secret / "outside.txt").write_text("synthetic outside authority")
        (self.source / "linked-file").symlink_to(secret / "outside.txt")
        (self.source / "linked-directory").symlink_to(secret, target_is_directory=True)
        selected, excluded = packer.scan_tree(self.source)
        self.assertEqual([row.path for row in selected], ["real.log"])
        self.assertEqual(sum(row["reason"] == "symlink_not_followed" for row in excluded), 2)
        linked_root = self.root / "linked-root"
        linked_root.symlink_to(self.source, target_is_directory=True)
        with self.assertRaises(OSError):
            packer.scan_tree(linked_root)

    def test_archive_is_complete_checksummed_regular_relative_and_source_unchanged(self):
        original = self.put("old-failed.log", "original FAILED output\n")
        self.put("commands/run.py", "# synthetic command helper\n")
        self.put("browser/fixture.png", b"\x89PNG\r\n\x1a\nsynthetic image fixture")
        before = original.read_bytes()
        result = self.publish()
        self.assertFalse(result["applicationTestsExecuted"])
        self.assertFalse(result["gitPushPerformed"])
        self.assertTrue(result["allSelectedEvidenceCoveredExactlyOnce"])
        self.assertEqual(original.read_bytes(), before)
        for receipt in result["archives"]:
            verified = packer.verify_archive(self.root / "published" / receipt["file"], receipt["sha256"])
            self.assertGreater(verified["verifiedRegularFiles"], 3)
            with tarfile.open(self.root / "published" / receipt["file"], "r:gz") as archive:
                members = archive.getmembers()
                self.assertTrue(all(row.isfile() and not row.linkname for row in members))
                self.assertEqual(archive.extractfile(packer.ARCHIVE_ROOT + "/evidence/old-failed.log").read(), before)

    def test_unsafe_tar_paths_are_rejected_without_extracting_anything(self):
        for number, name in enumerate(("/absolute", "../escape", "asset-accuracy-20261015/../escape", "asset-accuracy-20261015//bad")):
            archive_path = self.root / f"unsafe-{number}.tar.gz"
            with tarfile.open(archive_path, "w:gz") as archive:
                info = tarfile.TarInfo(name)
                info.size = 1
                archive.addfile(info, io.BytesIO(b"x"))
            with self.assertRaises(packer.EvidenceError):
                packer.verify_archive(archive_path)
        self.assertFalse((self.root / "escape").exists())

    def test_privacy_scan_has_no_matched_value_and_unreviewed_candidate_blocks_pack(self):
        synthetic = "sk-" + "z" * 32
        self.put("synthetic-candidate.log", synthetic)
        selected, _ = packer.scan_tree(self.source)
        hashes = {row.path: packer.file_digest(self.source, row) for row in selected}
        report = packer.privacy_scan(self.source, selected, hashes)
        self.assertGreater(report["candidateCount"], 0)
        self.assertNotIn(synthetic, json.dumps(report))
        with self.assertRaises(packer.EvidenceError):
            self.publish()
        self.assertFalse((self.root / "published").exists())
        review = self.root / "review.json"
        review.write_text(json.dumps({"decisions": [{**candidate,
            "decision": "publish_synthetic_or_nonsecret", "reviewNote": "Created by this packer-only unit test; no real account or secret"}
            for candidate in report["candidates"]]}))
        with self.assertRaises(packer.EvidenceError):
            self.publish(review=review)
        self.assertFalse((self.root / "published").exists())

    def test_mutation_during_archive_read_fails_without_final_output(self):
        record = self.put("changing.log", "original stable fixture")
        original_read = packer.HashingReader.read
        changed = False
        def changed_read(reader, size=-1):
            nonlocal changed
            data = original_read(reader, size)
            if not changed:
                changed = True
                record.write_text("changed during capture")
            return data
        with mock.patch.object(packer.HashingReader, "read", changed_read):
            with self.assertRaises(packer.EvidenceError):
                self.publish()
        self.assertFalse((self.root / "published").exists())

    def test_existing_output_is_never_overwritten_and_identical_inputs_are_reproducible(self):
        self.put("stable.log", "identical source fixture")
        first = self.publish("first")
        second = self.publish("second")
        self.assertEqual(first["archives"][0]["sha256"], second["archives"][0]["sha256"])
        marker = self.root / "first" / "marker"
        marker.write_text("keep")
        with self.assertRaises(packer.EvidenceError):
            self.publish("first")
        self.assertEqual(marker.read_text(), "keep")

    def test_changed_archive_member_fails_internal_checksum(self):
        self.put("proof.log", "unchanged proof")
        result = self.publish()
        original = self.root / "published" / result["archives"][0]["file"]
        tampered = self.root / "tampered.tar.gz"
        with tarfile.open(original, "r:gz") as source, tarfile.open(tampered, "w:gz") as target:
            for member in source:
                content = source.extractfile(member).read()
                if member.name.endswith("/proof.log"):
                    content = b"changed proof"
                member.size = len(content)
                target.addfile(member, io.BytesIO(content))
        with self.assertRaises(packer.EvidenceError):
            packer.verify_archive(tampered)

    def test_size_split_preserves_all_text_and_image_bytes_in_independent_parts(self):
        policy = json.loads(self.policy.read_text())
        policy["limits"]["maximumArchiveBytes"] = 1024 * 1024
        self.policy.write_text(json.dumps(policy))
        self.put("old-failed.log", "original failed evidence remains")
        self.put("browser/one.png", b"\x89PNG\r\n\x1a\n" + os.urandom(700 * 1024))
        self.put("browser/two.png", b"\x89PNG\r\n\x1a\n" + os.urandom(700 * 1024))
        result = self.publish()
        self.assertEqual(len(result["archives"]), 3)
        self.assertEqual({row["publicationPart"] for row in result["archives"]}, {"texts", "screenshots-01", "screenshots-02"})
        self.assertEqual(sum(row["selectedSourceFiles"] for row in result["archives"]), 3)
        for receipt in result["archives"]:
            self.assertLessEqual(receipt["bytes"], 1024 * 1024)
            packer.verify_archive(self.root / "published" / receipt["file"], receipt["sha256"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
